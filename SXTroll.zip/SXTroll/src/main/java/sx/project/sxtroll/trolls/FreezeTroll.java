package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class FreezeTroll extends BaseTroll {
    public FreezeTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "freeze", "&b❄ Заморозить", "Заморозить игрока на месте", Material.ICE, TrollCategory.EFFECTS);
    }

    @Override
    public void execute(Player target, Player executor) {
        if (manager.getFrozen().contains(target.getUniqueId())) {
            manager.getFrozen().remove(target.getUniqueId());
            target.removePotionEffect(PotionEffectType.SLOWNESS);
            target.setWalkSpeed(0.2f);
            plugin.getMessageUtils().send(executor, "troll.freeze.disabled", "{player}", target.getName());
        } else {
            manager.getFrozen().add(target.getUniqueId());
            target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, Integer.MAX_VALUE, 255, false, false));
            target.setWalkSpeed(0f);
            target.getWorld().spawnParticle(Particle.SNOWFLAKE, target.getLocation().add(0, 1, 0), 50, 0.5, 1, 0.5, 0.05);
            target.playSound(target.getLocation(), Sound.BLOCK_GLASS_BREAK, 1f, 1.5f);
            plugin.getMessageUtils().send(executor, "troll.freeze.enabled", "{player}", target.getName());
        }
    }

    @Override public boolean isToggle() { return true; }
    @Override public boolean isActive(Player target) { return manager.getFrozen().contains(target.getUniqueId()); }
}
