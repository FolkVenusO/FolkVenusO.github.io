package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;
import java.util.concurrent.ThreadLocalRandom;

public class ParanoiaTroll extends BaseTroll {
    public ParanoiaTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "paranoia", "&5👻 Паранойя", "Случайные жуткие звуки", Material.SOUL_LANTERN, TrollCategory.CHAT);
    }
    @Override
    public void execute(Player target, Player executor) {
        if (manager.getParanoid().contains(target.getUniqueId())) {
            manager.getParanoid().remove(target.getUniqueId());
            plugin.getMessageUtils().send(executor, "troll.default.disabled", "{player}", target.getName());
        } else {
            manager.getParanoid().add(target.getUniqueId());
            new BukkitRunnable() {
                @Override
                public void run() {
                    if (!target.isOnline() || !manager.getParanoid().contains(target.getUniqueId())) { cancel(); return; }
                    Sound[] sounds = {Sound.AMBIENT_CAVE, Sound.ENTITY_ENDERMAN_STARE, Sound.BLOCK_PORTAL_AMBIENT};
                    target.playSound(target.getLocation().add(ThreadLocalRandom.current().nextInt(-10, 10), 0, ThreadLocalRandom.current().nextInt(-10, 10)), sounds[ThreadLocalRandom.current().nextInt(sounds.length)], 0.5f, 1f);
                }
            }.runTaskTimer(plugin, 0L, 60L);
            plugin.getMessageUtils().send(executor, "troll.default.enabled", "{player}", target.getName());
        }
    }
    @Override public boolean isToggle() { return true; }
    @Override public boolean isActive(Player target) { return manager.getParanoid().contains(target.getUniqueId()); }
}
