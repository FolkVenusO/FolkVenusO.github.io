package sx.project.sxtroll.trolls;

import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class DemoScreenTroll extends BaseTroll {
    public DemoScreenTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "demo", "&e📺 Демо экран", "Показать демо экран", Material.PAINTING, TrollCategory.VISUAL);
    }
    @Override
    public void execute(Player target, Player executor) {
        target.showDemoScreen();
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
