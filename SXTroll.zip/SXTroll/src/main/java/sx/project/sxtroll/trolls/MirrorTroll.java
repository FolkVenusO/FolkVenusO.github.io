package sx.project.sxtroll.trolls;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class MirrorTroll extends BaseTroll {
    public MirrorTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "mirror", "&b🪞 Зеркало", "Инвертировать движения игрока", Material.GLASS, TrollCategory.SPECIAL);
    }

    @Override
    public void execute(Player target, Player executor) {
        new BukkitRunnable() {
            int ticks = 0;
            Location lastLoc = target.getLocation().clone();
            @Override
            public void run() {
                if (!target.isOnline() || ticks >= 200) { cancel(); return; }
                
                Location current = target.getLocation();
                double dx = current.getX() - lastLoc.getX();
                double dz = current.getZ() - lastLoc.getZ();
                
                if (Math.abs(dx) > 0.01 || Math.abs(dz) > 0.01) {
                    // Телепортируем в противоположном направлении
                    Location newLoc = current.clone();
                    newLoc.setX(current.getX() - dx * 2);
                    newLoc.setZ(current.getZ() - dz * 2);
                    newLoc.setYaw(current.getYaw());
                    newLoc.setPitch(current.getPitch());
                    target.teleport(newLoc);
                }
                
                lastLoc = target.getLocation().clone();
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
