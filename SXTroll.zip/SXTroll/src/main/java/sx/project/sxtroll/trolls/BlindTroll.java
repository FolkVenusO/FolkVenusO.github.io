package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class BlindTroll extends BaseTroll {
    public BlindTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "blind", "&8👁 Ослепить", "Ослепить игрока", Material.INK_SAC, TrollCategory.EFFECTS);
    }

    @Override
    public void execute(Player target, Player executor) {
        if (manager.getBlinded().contains(target.getUniqueId())) {
            manager.getBlinded().remove(target.getUniqueId());
            target.removePotionEffect(PotionEffectType.BLINDNESS);
            target.removePotionEffect(PotionEffectType.DARKNESS);
            plugin.getMessageUtils().send(executor, "troll.blind.disabled", "{player}", target.getName());
        } else {
            manager.getBlinded().add(target.getUniqueId());
            target.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, Integer.MAX_VALUE, 1, false, false));
            target.addPotionEffect(new PotionEffect(PotionEffectType.DARKNESS, Integer.MAX_VALUE, 1, false, false));
            target.playSound(target.getLocation(), Sound.ENTITY_WITHER_AMBIENT, 0.5f, 0.5f);
            plugin.getMessageUtils().send(executor, "troll.blind.enabled", "{player}", target.getName());
        }
    }

    @Override public boolean isToggle() { return true; }
    @Override public boolean isActive(Player target) { return manager.getBlinded().contains(target.getUniqueId()); }
}
