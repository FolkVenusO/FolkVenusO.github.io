package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class FakeExplosionTroll extends BaseTroll {
    public FakeExplosionTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "fakeexp", "&c💥 Фейк взрыв", "Фейковый взрыв", Material.TNT, TrollCategory.VISUAL);
    }
    @Override
    public void execute(Player target, Player executor) {
        target.getWorld().spawnParticle(Particle.EXPLOSION_EMITTER, target.getLocation(), 5, 1, 1, 1, 0);
        target.playSound(target.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 1f, 1f);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
