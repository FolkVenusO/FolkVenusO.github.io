package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;
import java.util.concurrent.ThreadLocalRandom;

public class FakeMessageTroll extends BaseTroll {
    private static final String[] MESSAGES = {"§c[Сервер] §fВы были помечены античитом!", "§c[Сервер] §fОбнаружена подозрительная активность...", "§4[ВНИМАНИЕ] §cВаш аккаунт будет проверен!", "§e[Система] §fВаш инвентарь синхронизируется...", "§c[AntiCheat] §fWarning: Suspicious movement detected!"};
    public FakeMessageTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "fakemsg", "&c📨 Фейк сообщение", "Отправить пугающее сообщение", Material.PAPER, TrollCategory.CHAT);
    }
    @Override
    public void execute(Player target, Player executor) {
        target.sendMessage(MESSAGES[ThreadLocalRandom.current().nextInt(MESSAGES.length)]);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
