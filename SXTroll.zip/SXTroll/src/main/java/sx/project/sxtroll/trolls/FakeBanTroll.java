package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class FakeBanTroll extends BaseTroll {
    public FakeBanTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "fakeban", "&c🔨 Фейк бан", "Фейковое сообщение о бане", Material.BARRIER, TrollCategory.CHAT);
    }
    @Override
    public void execute(Player target, Player executor) {
        target.sendMessage("");
        target.sendMessage("§c§l⚠ ВЫ БЫЛИ ЗАБАНЕНЫ ⚠");
        target.sendMessage("§7Причина: §fИспользование читов");
        target.sendMessage("§7Истекает: §fНикогда");
        target.sendMessage("§7Обжалование: §fdiscord.gg/appeal");
        target.sendMessage("");
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
