package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class GlowTroll extends BaseTroll {
    public GlowTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "glow", "&e✨ Свечение", "Дать свечение игроку", Material.GLOWSTONE_DUST, TrollCategory.EFFECTS);
    }

    @Override
    public void execute(Player target, Player executor) {
        target.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 20 * 120, 0, false, false));
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
