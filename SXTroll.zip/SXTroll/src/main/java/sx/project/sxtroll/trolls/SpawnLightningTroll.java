package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class SpawnLightningTroll extends BaseTroll {
    public SpawnLightningTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "lightning", "&e⚡ Молния", "Ударить молнией", Material.END_ROD, TrollCategory.MOBS);
    }
    @Override
    public void execute(Player target, Player executor) {
        target.getWorld().strikeLightning(target.getLocation());
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
