package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class WitherTroll extends BaseTroll {
    public WitherTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "wither", "&8💀 Иссушение", "Дать иссушение игроку", Material.WITHER_SKELETON_SKULL, TrollCategory.EFFECTS);
    }

    @Override
    public void execute(Player target, Player executor) {
        target.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 20 * 20, 1, false, true));
        target.playSound(target.getLocation(), Sound.ENTITY_WITHER_SPAWN, 0.5f, 1f);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
