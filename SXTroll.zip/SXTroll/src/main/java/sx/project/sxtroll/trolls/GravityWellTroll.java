package sx.project.sxtroll.trolls;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class GravityWellTroll extends BaseTroll {
    public GravityWellTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "gravitywell", "&9🔮 Гравитационный колодец", "Притянуть к точке и подбросить", Material.AMETHYST_SHARD, TrollCategory.TELEPORT);
    }

    @Override
    public void execute(Player target, Player executor) {
        Location well = target.getLocation().clone();
        target.playSound(well, Sound.BLOCK_BEACON_ACTIVATE, 1f, 0.5f);
        
        new BukkitRunnable() {
            int phase = 0; // 0 = притягивание, 1 = выброс
            int ticks = 0;
            double spiralAngle = 0;
            @Override
            public void run() {
                if (!target.isOnline() || ticks >= 100) { cancel(); return; }
                
                // Визуал воронки
                for (double y = 0; y < 3; y += 0.2) {
                    double radius = (3 - y) * 0.5;
                    double x = Math.cos(spiralAngle + y * 2) * radius;
                    double z = Math.sin(spiralAngle + y * 2) * radius;
                    well.getWorld().spawnParticle(Particle.END_ROD, well.clone().add(x, y, z), 1, 0, 0, 0, 0);
                }
                spiralAngle += 0.3;
                
                if (phase == 0 && ticks < 60) {
                    // Притягиваем
                    Vector toWell = well.toVector().subtract(target.getLocation().toVector());
                    if (toWell.length() > 0.5) {
                        target.setVelocity(toWell.normalize().multiply(0.4));
                    }
                } else if (phase == 0) {
                    phase = 1;
                    // ВЫБРОС!
                    target.setVelocity(new Vector(0, 2.5, 0));
                    target.getWorld().spawnParticle(Particle.FLASH, target.getLocation(), 1, 0, 0, 0, 0);
                    target.playSound(target.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_LAUNCH, 1f, 0.5f);
                }
                
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
