package sx.project.sxtroll.trolls;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;
import java.util.concurrent.ThreadLocalRandom;

public class GlitchyTroll extends BaseTroll {
    public GlitchyTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "glitchy", "&c📺 Глитч", "Эффект глитча", Material.STRUCTURE_VOID, TrollCategory.VISUAL);
    }
    @Override
    public void execute(Player target, Player executor) {
        if (manager.getGlitchy().contains(target.getUniqueId())) {
            manager.getGlitchy().remove(target.getUniqueId());
            plugin.getMessageUtils().send(executor, "troll.default.disabled", "{player}", target.getName());
        } else {
            manager.getGlitchy().add(target.getUniqueId());
            new BukkitRunnable() {
                @Override
                public void run() {
                    if (!target.isOnline() || !manager.getGlitchy().contains(target.getUniqueId())) { cancel(); return; }
                    Location loc = target.getLocation();
                    loc.add(ThreadLocalRandom.current().nextDouble(-0.5, 0.5), 0, ThreadLocalRandom.current().nextDouble(-0.5, 0.5));
                    target.teleport(loc);
                }
            }.runTaskTimer(plugin, 0L, 10L);
            plugin.getMessageUtils().send(executor, "troll.default.enabled", "{player}", target.getName());
        }
    }
    @Override public boolean isToggle() { return true; }
    @Override public boolean isActive(Player target) { return manager.getGlitchy().contains(target.getUniqueId()); }
}
