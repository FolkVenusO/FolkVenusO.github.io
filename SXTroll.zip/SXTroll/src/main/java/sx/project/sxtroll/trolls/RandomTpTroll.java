package sx.project.sxtroll.trolls;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;
import java.util.concurrent.ThreadLocalRandom;

public class RandomTpTroll extends BaseTroll {
    public RandomTpTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "randomtp", "&5🌀 Случайный ТП", "Телепортировать в случайное место", Material.ENDER_PEARL, TrollCategory.TELEPORT);
    }

    @Override
    public void execute(Player target, Player executor) {
        Location loc = target.getLocation();
        double x = loc.getX() + ThreadLocalRandom.current().nextInt(-50, 50);
        double z = loc.getZ() + ThreadLocalRandom.current().nextInt(-50, 50);
        double y = target.getWorld().getHighestBlockYAt((int)x, (int)z) + 1;
        
        target.teleport(new Location(target.getWorld(), x, y, z, loc.getYaw(), loc.getPitch()));
        target.playSound(target.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1f);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
