package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class FakeHackerTroll extends BaseTroll {
    public FakeHackerTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "hacker", "&c💻 Хакер атака", "Фейковая хакерская атака", Material.REDSTONE, TrollCategory.CHAT);
    }
    @Override
    public void execute(Player target, Player executor) {
        String[] msgs = {"§c[ВЗЛОМ] §fПодключение к серверу...", "§c[ВЗЛОМ] §fСканирование портов...", "§c[ВЗЛОМ] §fДоступ получен!", "§c[ВЗЛОМ] §fЗагрузка вируса... 45%", "§c[ВЗЛОМ] §fУдаление inventory.dat...", "§a[ВЗЛОМ] §fОтменено администратором."};
        new BukkitRunnable() {
            int i = 0;
            @Override
            public void run() {
                if (!target.isOnline() || i >= msgs.length) { cancel(); return; }
                target.sendMessage(msgs[i++]);
            }
        }.runTaskTimer(plugin, 0L, 20L);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
