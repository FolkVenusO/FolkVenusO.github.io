package sx.project.sxtroll.utils;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import sx.project.sxtroll.SXTrollPlugin;

public class MessageUtils {

    private final SXTrollPlugin plugin;
    private final String prefix;
    private final LegacyComponentSerializer legacy = LegacyComponentSerializer.legacyAmpersand();
    private final MiniMessage mini = MiniMessage.miniMessage();

    public MessageUtils(SXTrollPlugin plugin) {
        this.plugin = plugin;
        this.prefix = plugin.getConfig().getString("messages.prefix", "&8[&b&lSX&f&lTroll&8] &r");
    }

    public void send(CommandSender sender, String key, String... replacements) {
        String message = plugin.getConfig().getString("messages." + key, key);
        
        for (int i = 0; i < replacements.length - 1; i += 2) {
            message = message.replace(replacements[i], replacements[i + 1]);
        }
        
        sender.sendMessage(legacy.deserialize(prefix + message));
    }

    public void sendRaw(CommandSender sender, String message) {
        sender.sendMessage(legacy.deserialize(message));
    }

    public Component colorize(String text) {
        return legacy.deserialize(text);
    }

    public String getPrefix() {
        return prefix;
    }
}
