package sx.project.sxtroll.trolls;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class VoidTroll extends BaseTroll {
    public VoidTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "void", "&0🕳 В войд", "Телепортировать в войд", Material.BLACK_CONCRETE, TrollCategory.TELEPORT);
    }

    @Override
    public void execute(Player target, Player executor) {
        Location loc = target.getLocation();
        loc.setY(-60);
        target.teleport(loc);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
