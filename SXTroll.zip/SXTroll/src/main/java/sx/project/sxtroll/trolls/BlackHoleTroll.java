package sx.project.sxtroll.trolls;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class BlackHoleTroll extends BaseTroll {
    public BlackHoleTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "blackhole", "&8🌀 Чёрная дыра", "Создать чёрную дыру, притягивающую всё", Material.BLACK_CONCRETE, TrollCategory.SPECIAL);
    }

    @Override
    public void execute(Player target, Player executor) {
        Location center = target.getLocation();
        new BukkitRunnable() {
            int ticks = 0;
            double angle = 0;
            @Override
            public void run() {
                if (ticks >= 100) { cancel(); return; }
                
                // Визуальный эффект спирали
                for (int i = 0; i < 3; i++) {
                    double x = Math.cos(angle + i * 2) * (3 - ticks * 0.02);
                    double z = Math.sin(angle + i * 2) * (3 - ticks * 0.02);
                    center.getWorld().spawnParticle(Particle.PORTAL, center.clone().add(x, 1, z), 5, 0, 0, 0, 0);
                    center.getWorld().spawnParticle(Particle.SMOKE, center.clone().add(x, 1, z), 2, 0, 0, 0, 0);
                }
                angle += 0.3;
                
                // Притягиваем игрока
                if (target.isOnline() && target.getLocation().distance(center) > 1) {
                    Vector pull = center.toVector().subtract(target.getLocation().toVector()).normalize().multiply(0.3);
                    target.setVelocity(pull);
                }
                
                // Звук каждые 20 тиков
                if (ticks % 20 == 0) {
                    target.playSound(center, Sound.BLOCK_PORTAL_AMBIENT, 0.5f, 0.5f);
                }
                
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
