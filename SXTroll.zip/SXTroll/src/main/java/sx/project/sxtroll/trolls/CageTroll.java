package sx.project.sxtroll.trolls;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class CageTroll extends BaseTroll {
    public CageTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "cage", "&8🔒 Клетка", "Посадить в клетку", Material.IRON_BARS, TrollCategory.SPECIAL);
    }
    @Override
    public void execute(Player target, Player executor) {
        Location loc = target.getLocation();
        for (int x = -1; x <= 1; x++) for (int z = -1; z <= 1; z++) {
            loc.clone().add(x, -1, z).getBlock().setType(Material.BEDROCK);
            loc.clone().add(x, 3, z).getBlock().setType(Material.BEDROCK);
        }
        for (int y = 0; y <= 2; y++) {
            loc.clone().add(-1, y, -1).getBlock().setType(Material.IRON_BARS);
            loc.clone().add(-1, y, 1).getBlock().setType(Material.IRON_BARS);
            loc.clone().add(1, y, -1).getBlock().setType(Material.IRON_BARS);
            loc.clone().add(1, y, 1).getBlock().setType(Material.IRON_BARS);
            loc.clone().add(0, y, -1).getBlock().setType(Material.IRON_BARS);
            loc.clone().add(0, y, 1).getBlock().setType(Material.IRON_BARS);
            loc.clone().add(-1, y, 0).getBlock().setType(Material.IRON_BARS);
            loc.clone().add(1, y, 0).getBlock().setType(Material.IRON_BARS);
        }
        new BukkitRunnable() {
            @Override
            public void run() {
                for (int x = -1; x <= 1; x++) for (int z = -1; z <= 1; z++) {
                    loc.clone().add(x, -1, z).getBlock().setType(Material.AIR);
                    loc.clone().add(x, 3, z).getBlock().setType(Material.AIR);
                }
                for (int y = 0; y <= 2; y++) for (int x = -1; x <= 1; x++) for (int z = -1; z <= 1; z++)
                    if (loc.clone().add(x, y, z).getBlock().getType() == Material.IRON_BARS)
                        loc.clone().add(x, y, z).getBlock().setType(Material.AIR);
            }
        }.runTaskLater(plugin, 200L);
        plugin.getMessageUtils().send(executor, "troll.cage.executed", "{player}", target.getName());
    }
}
