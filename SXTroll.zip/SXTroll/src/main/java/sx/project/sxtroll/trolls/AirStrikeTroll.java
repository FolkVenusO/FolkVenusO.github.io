package sx.project.sxtroll.trolls;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;
import java.util.concurrent.ThreadLocalRandom;

public class AirStrikeTroll extends BaseTroll {
    public AirStrikeTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "airstrike", "&4✈ Авиаудар", "Вызвать авиаудар", Material.FIREWORK_ROCKET, TrollCategory.SPECIAL);
    }

    @Override
    public void execute(Player target, Player executor) {
        target.sendMessage("§c§l⚠ ВНИМАНИЕ! Авиаудар через 5 секунд! ⚠");
        target.playSound(target.getLocation(), Sound.ENTITY_ELDER_GUARDIAN_CURSE, 1f, 2f);
        
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (!target.isOnline()) return;
            
            Location center = target.getLocation();
            new BukkitRunnable() {
                int count = 0;
                @Override
                public void run() {
                    if (!target.isOnline() || count >= 15) { cancel(); return; }
                    
                    double x = center.getX() + ThreadLocalRandom.current().nextDouble(-5, 5);
                    double z = center.getZ() + ThreadLocalRandom.current().nextDouble(-5, 5);
                    Location strike = new Location(center.getWorld(), x, center.getY() + 30, z);
                    
                    // Частицы падающей бомбы
                    new BukkitRunnable() {
                        Location current = strike.clone();
                        @Override
                        public void run() {
                            if (current.getY() <= center.getY()) {
                                // Взрыв
                                current.getWorld().spawnParticle(Particle.EXPLOSION_EMITTER, current, 1, 0, 0, 0, 0);
                                current.getWorld().playSound(current, Sound.ENTITY_GENERIC_EXPLODE, 1f, 1f);
                                cancel();
                                return;
                            }
                            current.getWorld().spawnParticle(Particle.FLAME, current, 5, 0.1, 0.1, 0.1, 0.02);
                            current.getWorld().spawnParticle(Particle.SMOKE, current, 3, 0.1, 0.1, 0.1, 0.01);
                            current.subtract(0, 2, 0);
                        }
                    }.runTaskTimer(plugin, 0L, 1L);
                    
                    count++;
                }
            }.runTaskTimer(plugin, 0L, 5L);
            
        }, 100L);
        
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
