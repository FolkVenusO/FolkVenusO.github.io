package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class LaunchTroll extends BaseTroll {
    public LaunchTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "launch", "&c⬆ Подбросить", "Подбросить игрока в воздух", Material.PISTON, TrollCategory.TELEPORT);
    }

    @Override
    public void execute(Player target, Player executor) {
        target.setVelocity(new Vector(0, 3, 0));
        target.playSound(target.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_LAUNCH, 1f, 1f);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
