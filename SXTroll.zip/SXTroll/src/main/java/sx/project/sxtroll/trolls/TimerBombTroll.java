package sx.project.sxtroll.trolls;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.title.Title;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;
import java.time.Duration;

public class TimerBombTroll extends BaseTroll {
    public TimerBombTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "timerbomb", "&c⏱ Бомба с таймером", "Обратный отсчёт до взрыва", Material.CLOCK, TrollCategory.SPECIAL);
    }

    @Override
    public void execute(Player target, Player executor) {
        new BukkitRunnable() {
            int seconds = 10;
            @Override
            public void run() {
                if (!target.isOnline()) { cancel(); return; }
                
                if (seconds > 0) {
                    NamedTextColor color = seconds <= 3 ? NamedTextColor.RED : NamedTextColor.YELLOW;
                    Title title = Title.title(
                        Component.text("💣 " + seconds + " 💣", color),
                        Component.text("БОМБА ВЗОРВЁТСЯ!", NamedTextColor.GRAY),
                        Title.Times.times(Duration.ZERO, Duration.ofMillis(1100), Duration.ZERO)
                    );
                    target.showTitle(title);
                    target.playSound(target.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1f, seconds <= 3 ? 2f : 1f);
                    seconds--;
                } else {
                    // ВЗРЫВ (фейковый)
                    target.getWorld().spawnParticle(Particle.EXPLOSION_EMITTER, target.getLocation(), 3, 1, 1, 1, 0);
                    target.playSound(target.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 1f, 1f);
                    Title title = Title.title(
                        Component.text("💥 БУМ! 💥", NamedTextColor.RED),
                        Component.text("Шутка :)", NamedTextColor.GREEN),
                        Title.Times.times(Duration.ZERO, Duration.ofSeconds(2), Duration.ofMillis(500))
                    );
                    target.showTitle(title);
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 0L, 20L);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
