package sx.project.sxtroll.trolls;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class DropTroll extends BaseTroll {
    public DropTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "drop", "&4⬇ Сбросить", "Телепортировать высоко и сбросить", Material.FEATHER, TrollCategory.TELEPORT);
    }

    @Override
    public void execute(Player target, Player executor) {
        Location loc = target.getLocation();
        loc.setY(loc.getY() + 100);
        target.teleport(loc);
        target.playSound(target.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1f);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
