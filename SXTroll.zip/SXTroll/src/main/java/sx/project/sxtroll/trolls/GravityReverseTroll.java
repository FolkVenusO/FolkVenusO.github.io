package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class GravityReverseTroll extends BaseTroll {
    public GravityReverseTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "antigrav", "&5⬆ Антигравитация", "Обратить гравитацию", Material.END_CRYSTAL, TrollCategory.TELEPORT);
    }

    @Override
    public void execute(Player target, Player executor) {
        if (manager.getGravityReverse().contains(target.getUniqueId())) {
            manager.getGravityReverse().remove(target.getUniqueId());
            target.removePotionEffect(PotionEffectType.LEVITATION);
            target.setGravity(true);
            plugin.getMessageUtils().send(executor, "troll.default.disabled", "{player}", target.getName());
        } else {
            manager.getGravityReverse().add(target.getUniqueId());
            target.addPotionEffect(new PotionEffect(PotionEffectType.LEVITATION, Integer.MAX_VALUE, 1, false, false));
            plugin.getMessageUtils().send(executor, "troll.default.enabled", "{player}", target.getName());
        }
    }

    @Override public boolean isToggle() { return true; }
    @Override public boolean isActive(Player target) { return manager.getGravityReverse().contains(target.getUniqueId()); }
}
