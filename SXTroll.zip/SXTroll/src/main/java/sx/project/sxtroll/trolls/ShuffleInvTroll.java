package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ShuffleInvTroll extends BaseTroll {
    public ShuffleInvTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "shuffle", "&e🔀 Перемешать инв", "Перемешать инвентарь", Material.HOPPER, TrollCategory.INVENTORY);
    }

    @Override
    public void execute(Player target, Player executor) {
        ItemStack[] contents = target.getInventory().getContents();
        List<ItemStack> list = Arrays.asList(contents);
        Collections.shuffle(list);
        target.getInventory().setContents(list.toArray(new ItemStack[0]));
        target.playSound(target.getLocation(), Sound.ENTITY_SHULKER_BULLET_HURT, 1f, 1f);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
