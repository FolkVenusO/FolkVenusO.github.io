package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.enchantments.Enchantment;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;
import java.util.List;

public class ExplosiveArrowsTroll extends BaseTroll {
    public ExplosiveArrowsTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "expbow", "&c🏹 Взрывной лук", "Дать взрывной лук", Material.BOW, TrollCategory.SPECIAL);
    }
    @Override
    public void execute(Player target, Player executor) {
        ItemStack bow = new ItemStack(Material.BOW);
        ItemMeta meta = bow.getItemMeta();
        meta.displayName(Component.text("☠ Взрывной Лук", NamedTextColor.RED));
        meta.lore(List.of(Component.text("Каждая стрела взрывается!", NamedTextColor.GRAY)));
        meta.addEnchant(Enchantment.POWER, 5, true);
        meta.addEnchant(Enchantment.FLAME, 1, true);
        bow.setItemMeta(meta);
        target.getInventory().addItem(bow, new ItemStack(Material.ARROW, 16));
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
