package sx.project.sxtroll.trolls;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;
import java.util.concurrent.ThreadLocalRandom;

public class MatrixTroll extends BaseTroll {
    private final String chars = "ァアィイゥウェエォオカガキギクグケゲコゴサザシジスズセゼソゾタダチヂッツヅテデトドナニヌネノハバパヒビピフブプヘベペホボポマミムメモャヤュユョヨラリルレロワヰヱヲン0123456789";
    public MatrixTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "matrix", "&a🖥 Матрица", "Эффект матрицы", Material.LIME_STAINED_GLASS, TrollCategory.VISUAL);
    }
    @Override
    public void execute(Player target, Player executor) {
        new BukkitRunnable() {
            int lines = 0;
            @Override
            public void run() {
                if (!target.isOnline() || lines >= 20) { cancel(); return; }
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < 50; i++) sb.append(chars.charAt(ThreadLocalRandom.current().nextInt(chars.length())));
                target.sendMessage(Component.text(sb.toString(), NamedTextColor.GREEN));
                target.playSound(target.getLocation(), Sound.BLOCK_NOTE_BLOCK_BIT, 0.3f, 2f);
                lines++;
            }
        }.runTaskTimer(plugin, 0L, 2L);
        plugin.getMessageUtils().send(executor, "troll.matrix.executed", "{player}", target.getName());
    }
}
