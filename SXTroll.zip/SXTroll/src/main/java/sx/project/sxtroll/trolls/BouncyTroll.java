package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class BouncyTroll extends BaseTroll {
    public BouncyTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "bouncy", "&d🏀 Батут", "Постоянно подпрыгивать", Material.SLIME_BLOCK, TrollCategory.VISUAL);
    }
    @Override
    public void execute(Player target, Player executor) {
        if (manager.getBouncy().contains(target.getUniqueId())) {
            manager.getBouncy().remove(target.getUniqueId());
            plugin.getMessageUtils().send(executor, "troll.default.disabled", "{player}", target.getName());
        } else {
            manager.getBouncy().add(target.getUniqueId());
            new BukkitRunnable() {
                @Override
                public void run() {
                    if (!target.isOnline() || !manager.getBouncy().contains(target.getUniqueId())) { cancel(); return; }
                    if (target.isOnGround()) target.setVelocity(new Vector(0, 1, 0));
                }
            }.runTaskTimer(plugin, 0L, 5L);
            plugin.getMessageUtils().send(executor, "troll.default.enabled", "{player}", target.getName());
        }
    }
    @Override public boolean isToggle() { return true; }
    @Override public boolean isActive(Player target) { return manager.getBouncy().contains(target.getUniqueId()); }
}
