package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class PoisonTroll extends BaseTroll {
    public PoisonTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "poison", "&a☠ Отравить", "Отравить игрока", Material.SPIDER_EYE, TrollCategory.EFFECTS);
    }

    @Override
    public void execute(Player target, Player executor) {
        target.addPotionEffect(new PotionEffect(PotionEffectType.POISON, 20 * 30, 2, false, true));
        target.playSound(target.getLocation(), Sound.ENTITY_SPIDER_AMBIENT, 1f, 0.8f);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
