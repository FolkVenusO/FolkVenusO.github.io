package sx.project.sxtroll.listeners;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.gui.TrollGUI;
import sx.project.sxtroll.trolls.BaseTroll;

import java.util.List;
import java.util.UUID;

public class GUIListener implements Listener {

    private final SXTrollPlugin plugin;

    public GUIListener(SXTrollPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        
        String title = event.getView().getTitle();
        
        // Проверяем что это наше меню
        if (!title.contains("SXTroll")) return;
        
        event.setCancelled(true);
        
        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getType() == Material.AIR) return;
        if (clicked.getType().name().contains("GLASS_PANE")) return;
        
        TrollGUI gui = plugin.getTrollGUI();
        
        // ═══════════════════ МЕНЮ ВЫБОРА ИГРОКА ═══════════════════
        if (title.contains("Выбор цели")) {
            handlePlayerSelectMenu(player, clicked, gui);
            return;
        }
        
        // ═══════════════════ МЕНЮ КАТЕГОРИЙ ═══════════════════
        if (title.contains("Категории")) {
            handleCategoryMenu(player, clicked, event.getSlot(), gui);
            return;
        }
        
        // ═══════════════════ МЕНЮ ТРОЛЛЕЙ ═══════════════════
        handleTrollsMenu(player, clicked, event.getSlot(), gui);
    }

    private void handlePlayerSelectMenu(Player player, ItemStack clicked, TrollGUI gui) {
        gui.playClickSound(player);
        
        if (clicked.getType() == Material.PLAYER_HEAD) {
            SkullMeta meta = (SkullMeta) clicked.getItemMeta();
            if (meta.getOwningPlayer() != null) {
                Player target = meta.getOwningPlayer().getPlayer();
                if (target != null && target.isOnline()) {
                    // Проверка защиты
                    if (target.hasPermission("sxtroll.bypass") && !player.hasPermission("sxtroll.admin")) {
                        plugin.getMessageUtils().send(player, "player-protected");
                        player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
                        return;
                    }
                    gui.openCategoryMenu(player, target);
                }
            }
        } else if (clicked.getType() == Material.SUNFLOWER) {
            // Обновить список
            gui.openPlayerSelectMenu(player);
        } else if (clicked.getType() == Material.BOOK) {
            // Помощь
            player.closeInventory();
            player.sendMessage("");
            player.sendMessage("§8§m                                                §r");
            player.sendMessage("§b§l    ⚡ SXTroll - Помощь ⚡");
            player.sendMessage("");
            player.sendMessage("§e  /sxtroll §7- Открыть меню");
            player.sendMessage("§e  /sxtroll <игрок> §7- Выбрать цель");
            player.sendMessage("§e  /sxtroll <игрок> <тролль> §7- Применить тролль");
            player.sendMessage("§e  /sxtroll reload §7- Перезагрузить");
            player.sendMessage("");
            player.sendMessage("§7  Всего троллей: §a" + plugin.getTrollManager().getTrollCount());
            player.sendMessage("§8§m                                                §r");
            player.sendMessage("");
        }
    }

    private void handleCategoryMenu(Player player, ItemStack clicked, int slot, TrollGUI gui) {
        gui.playClickSound(player);
        
        UUID targetUUID = gui.getSelectedTarget(player);
        if (targetUUID == null) {
            gui.openPlayerSelectMenu(player);
            return;
        }
        
        Player target = Bukkit.getPlayer(targetUUID);
        if (target == null) {
            plugin.getMessageUtils().send(player, "target-offline");
            gui.openPlayerSelectMenu(player);
            return;
        }

        // Назад
        if (clicked.getType() == Material.ARROW) {
            gui.openPlayerSelectMenu(player);
            return;
        }
        
        // Очистить всё
        if (clicked.getType() == Material.WATER_BUCKET) {
            plugin.getTrollManager().clearPlayer(target);
            plugin.getMessageUtils().sendRaw(player, "&a&l✓ &aВсе эффекты сняты с &e" + target.getName());
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_SPLASH, 1f, 1f);
            gui.openCategoryMenu(player, target);
            return;
        }
        
        // Все троллы
        if (clicked.getType() == Material.NETHER_STAR) {
            gui.openTrollsMenu(player, null, 0);
            return;
        }
        
        // Опасные троллы (SPECIAL)
        if (clicked.getType() == Material.REDSTONE) {
            gui.openTrollsMenu(player, BaseTroll.TrollCategory.SPECIAL, 0);
            return;
        }
        
        // Категории
        for (BaseTroll.TrollCategory cat : BaseTroll.TrollCategory.values()) {
            if (clicked.getType() == cat.getIcon()) {
                gui.openTrollsMenu(player, cat, 0);
                return;
            }
        }
    }

    private void handleTrollsMenu(Player player, ItemStack clicked, int slot, TrollGUI gui) {
        gui.playClickSound(player);
        
        UUID targetUUID = gui.getSelectedTarget(player);
        if (targetUUID == null) {
            gui.openPlayerSelectMenu(player);
            return;
        }
        
        Player target = Bukkit.getPlayer(targetUUID);
        if (target == null) {
            plugin.getMessageUtils().send(player, "target-offline");
            gui.openPlayerSelectMenu(player);
            return;
        }

        // Назад к категориям
        if (slot == 45 && clicked.getType() == Material.ARROW) {
            gui.openCategoryMenu(player, target);
            return;
        }
        
        // Предыдущая страница
        if (slot == 48 && clicked.getType() == Material.SPECTRAL_ARROW) {
            int page = gui.getCurrentPage(player);
            gui.openTrollsMenu(player, gui.getCurrentCategory(player), page - 1);
            return;
        }
        
        // Следующая страница
        if (slot == 50 && clicked.getType() == Material.SPECTRAL_ARROW) {
            int page = gui.getCurrentPage(player);
            gui.openTrollsMenu(player, gui.getCurrentCategory(player), page + 1);
            return;
        }
        
        // Очистить
        if (slot == 53 && clicked.getType() == Material.WATER_BUCKET) {
            plugin.getTrollManager().clearPlayer(target);
            plugin.getMessageUtils().sendRaw(player, "&a&l✓ &aВсе эффекты сняты с &e" + target.getName());
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_SPLASH, 1f, 1f);
            gui.openTrollsMenu(player, gui.getCurrentCategory(player), gui.getCurrentPage(player));
            return;
        }
        
        // Клик на тролль (слоты 0-35)
        if (slot < 36) {
            BaseTroll.TrollCategory category = gui.getCurrentCategory(player);
            List<BaseTroll> trolls;
            
            if (category == null) {
                trolls = new java.util.ArrayList<>(plugin.getTrollManager().getAllTrolls());
            } else {
                trolls = plugin.getTrollManager().getTrollsByCategory(category);
            }
            
            int page = gui.getCurrentPage(player);
            int index = page * 36 + slot;
            
            if (index < trolls.size()) {
                BaseTroll troll = trolls.get(index);
                
                // Выполняем тролль
                troll.execute(target, player);
                gui.playSuccessSound(player);
                
                // Обновляем меню через небольшую задержку
                Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    if (player.isOnline()) {
                        gui.openTrollsMenu(player, category, page);
                    }
                }, 5L);
            }
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;
        
        String title = event.getView().getTitle();
        if (title.contains("SXTroll")) {
            // Проверяем, не открывается ли другое меню SXTroll
            // Если да - не очищаем данные
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (player.isOnline()) {
                    String newTitle = player.getOpenInventory().getTitle();
                    if (!newTitle.contains("SXTroll")) {
                        // Игрок вышел из меню полностью - очищаем данные
                        plugin.getTrollGUI().clearData(player);
                    }
                }
            }, 1L);
        }
    }
}
