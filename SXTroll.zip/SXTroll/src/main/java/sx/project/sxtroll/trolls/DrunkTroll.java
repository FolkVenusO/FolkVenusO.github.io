package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class DrunkTroll extends BaseTroll {
    public DrunkTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "drunk", "&6🍺 Пьяный", "Сделать игрока пьяным", Material.HONEY_BOTTLE, TrollCategory.EFFECTS);
    }

    @Override
    public void execute(Player target, Player executor) {
        if (manager.getDrunk().contains(target.getUniqueId())) {
            manager.getDrunk().remove(target.getUniqueId());
            target.removePotionEffect(PotionEffectType.NAUSEA);
            target.removePotionEffect(PotionEffectType.SLOWNESS);
            plugin.getMessageUtils().send(executor, "troll.default.disabled", "{player}", target.getName());
        } else {
            manager.getDrunk().add(target.getUniqueId());
            target.addPotionEffect(new PotionEffect(PotionEffectType.NAUSEA, Integer.MAX_VALUE, 1, false, false));
            target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, Integer.MAX_VALUE, 1, false, false));
            plugin.getMessageUtils().send(executor, "troll.default.enabled", "{player}", target.getName());
        }
    }

    @Override public boolean isToggle() { return true; }
    @Override public boolean isActive(Player target) { return manager.getDrunk().contains(target.getUniqueId()); }
}
