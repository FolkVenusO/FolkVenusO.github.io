package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class RemoveArmorTroll extends BaseTroll {
    public RemoveArmorTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "striparmor", "&7🛡 Снять броню", "Снять броню с игрока", Material.IRON_CHESTPLATE, TrollCategory.INVENTORY);
    }

    @Override
    public void execute(Player target, Player executor) {
        target.getInventory().setHelmet(null);
        target.getInventory().setChestplate(null);
        target.getInventory().setLeggings(null);
        target.getInventory().setBoots(null);
        target.playSound(target.getLocation(), Sound.ITEM_ARMOR_EQUIP_GENERIC, 1f, 0.5f);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
