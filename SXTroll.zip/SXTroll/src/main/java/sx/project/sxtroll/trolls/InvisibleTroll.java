package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class InvisibleTroll extends BaseTroll {
    public InvisibleTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "invisible", "&f👻 Невидимость", "Дать невидимость игроку", Material.GLASS, TrollCategory.EFFECTS);
    }

    @Override
    public void execute(Player target, Player executor) {
        target.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 20 * 60, 0, false, false));
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
