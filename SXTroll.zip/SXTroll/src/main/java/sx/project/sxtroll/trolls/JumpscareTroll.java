package sx.project.sxtroll.trolls;

import net.kyori.adventure.title.Title;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;
import java.time.Duration;

public class JumpscareTroll extends BaseTroll {
    public JumpscareTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "jumpscare", "&4😱 Скример", "Показать скример", Material.CARVED_PUMPKIN, TrollCategory.CHAT);
    }
    @Override
    public void execute(Player target, Player executor) {
        Title title = Title.title(Component.text("☠☠☠", NamedTextColor.DARK_RED), Component.text("БУ!", NamedTextColor.RED), Title.Times.times(Duration.ofMillis(0), Duration.ofSeconds(2), Duration.ofMillis(500)));
        target.showTitle(title);
        target.playSound(target.getLocation(), Sound.ENTITY_GHAST_SCREAM, 1f, 0.5f);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
