package sx.project.sxtroll.listeners;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.player.*;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class TrollListener implements Listener {

    private final SXTrollPlugin plugin;
    private final TrollManager manager;

    public TrollListener(SXTrollPlugin plugin) {
        this.plugin = plugin;
        this.manager = plugin.getTrollManager();
    }

    @EventHandler(priority = EventPriority.LOW)
    public void onPlayerMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        
        // Заморозка
        if (manager.isFrozen(player)) {
            if (event.getFrom().getX() != event.getTo().getX() ||
                event.getFrom().getZ() != event.getTo().getZ()) {
                event.setTo(event.getFrom());
            }
        }
        
        // Блокировка прыжка
        if (manager.isNoJump(player)) {
            if (event.getTo().getY() > event.getFrom().getY() && !player.isFlying()) {
                event.setTo(event.getFrom());
            }
        }
    }

    @EventHandler
    public void onPlayerChat(AsyncPlayerChatEvent event) {
        if (manager.isNoChat(event.getPlayer())) {
            event.setCancelled(true);
            event.getPlayer().sendMessage("§c§oВы не можете говорить...");
        }
    }

    @EventHandler
    public void onPlayerCommand(PlayerCommandPreprocessEvent event) {
        if (manager.isNoCommands(event.getPlayer())) {
            event.setCancelled(true);
            event.getPlayer().sendMessage("§c§oКоманды заблокированы...");
        }
    }

    @EventHandler
    public void onItemPickup(EntityPickupItemEvent event) {
        if (event.getEntity() instanceof Player player) {
            if (manager.isNoPickup(player)) {
                event.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onItemDrop(PlayerDropItemEvent event) {
        if (manager.isNoDrop(event.getPlayer())) {
            event.setCancelled(true);
            event.getPlayer().sendMessage("§c§oВы не можете выбрасывать предметы...");
        }
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        if (manager.isNoBreak(event.getPlayer())) {
            event.setCancelled(true);
            event.getPlayer().sendMessage("§c§oВы не можете ломать блоки...");
        }
    }

    @EventHandler
    public void onBlockPlace(BlockPlaceEvent event) {
        if (manager.isNoPlace(event.getPlayer())) {
            event.setCancelled(true);
            event.getPlayer().sendMessage("§c§oВы не можете ставить блоки...");
        }
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        manager.clearPlayer(event.getPlayer());
        plugin.getTrollGUI().clearData(event.getPlayer());
    }
}
