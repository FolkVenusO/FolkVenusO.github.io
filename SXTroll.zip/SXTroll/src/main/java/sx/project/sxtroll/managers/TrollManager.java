package sx.project.sxtroll.managers;

import org.bukkit.entity.Player;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.trolls.*;

import java.util.*;

/**
 * Менеджер всех тролл-функций SX PROJECT
 */
public class TrollManager {

    private final SXTrollPlugin plugin;
    private final Map<String, BaseTroll> trolls = new LinkedHashMap<>();
    
    // Активные состояния для игроков
    private final Set<UUID> frozen = new HashSet<>();
    private final Set<UUID> blinded = new HashSet<>();
    private final Set<UUID> confused = new HashSet<>();
    private final Set<UUID> noPickup = new HashSet<>();
    private final Set<UUID> noDrop = new HashSet<>();
    private final Set<UUID> noChat = new HashSet<>();
    private final Set<UUID> noCommands = new HashSet<>();
    private final Set<UUID> invertedControls = new HashSet<>();
    private final Set<UUID> burning = new HashSet<>();
    private final Set<UUID> starving = new HashSet<>();
    private final Set<UUID> slowMining = new HashSet<>();
    private final Set<UUID> noJump = new HashSet<>();
    private final Set<UUID> bouncy = new HashSet<>();
    private final Set<UUID> drunk = new HashSet<>();
    private final Set<UUID> paranoid = new HashSet<>();
    private final Set<UUID> glitchy = new HashSet<>();
    private final Set<UUID> noBreak = new HashSet<>();
    private final Set<UUID> noPlace = new HashSet<>();
    private final Set<UUID> fakeOp = new HashSet<>();
    private final Set<UUID> gravityReverse = new HashSet<>();

    public TrollManager(SXTrollPlugin plugin) {
        this.plugin = plugin;
        registerTrolls();
    }

    private void registerTrolls() {
        // ═══════════════════ ЭФФЕКТЫ ═══════════════════
        register(new FreezeTroll(plugin, this));
        register(new BlindTroll(plugin, this));
        register(new ConfuseTroll(plugin, this));
        register(new BurnTroll(plugin, this));
        register(new StarveTroll(plugin, this));
        register(new PoisonTroll(plugin, this));
        register(new WitherTroll(plugin, this));
        register(new LevitationTroll(plugin, this));
        register(new SlownessTroll(plugin, this));
        register(new MiningFatigueTroll(plugin, this));
        register(new DrunkTroll(plugin, this));
        register(new GlowTroll(plugin, this));
        register(new InvisibleTroll(plugin, this));
        
        // ═══════════════════ ТЕЛЕПОРТАЦИЯ ═══════════════════
        register(new RandomTpTroll(plugin, this));
        register(new LaunchTroll(plugin, this));
        register(new DropTroll(plugin, this));
        register(new VoidTroll(plugin, this));
        register(new NetherTroll(plugin, this));
        register(new SkyTroll(plugin, this));
        register(new SpinTroll(plugin, this));
        register(new GravityReverseTroll(plugin, this));
        
        // ═══════════════════ ИНВЕНТАРЬ ═══════════════════
        register(new ClearInvTroll(plugin, this));
        register(new DropAllTroll(plugin, this));
        register(new ShuffleInvTroll(plugin, this));
        register(new FakeItemsTroll(plugin, this));
        register(new NoPickupTroll(plugin, this));
        register(new NoDropTroll(plugin, this));
        register(new RemoveArmorTroll(plugin, this));
        register(new SwapHandsTroll(plugin, this));
        register(new RandomSlotTroll(plugin, this));
        
        // ═══════════════════ МОБЫ ═══════════════════
        register(new SpawnCreeperTroll(plugin, this));
        register(new SpawnZombieTroll(plugin, this));
        register(new SpawnSkeletonTroll(plugin, this));
        register(new SpawnEndermanTroll(plugin, this));
        register(new SpawnLightningTroll(plugin, this));
        register(new SpawnTNTTroll(plugin, this));
        register(new AnvilRainTroll(plugin, this));
        register(new MobSwarmTroll(plugin, this));
        register(new SpawnWitherTroll(plugin, this));
        register(new BeeSwarmTroll(plugin, this));
        
        // ═══════════════════ ЧАТ И ЗВУКИ ═══════════════════
        register(new FakeSoundTroll(plugin, this));
        register(new FakeMessageTroll(plugin, this));
        register(new FakeOpTroll(plugin, this));
        register(new FakeDeathTroll(plugin, this));
        register(new FakeHackerTroll(plugin, this));
        register(new ParanoiaTroll(plugin, this));
        register(new FakeBanTroll(plugin, this));
        register(new FakeKickTroll(plugin, this));
        register(new JumpscareTroll(plugin, this));
        
        // ═══════════════════ БЛОКИРОВКИ ═══════════════════
        register(new NoChatTroll(plugin, this));
        register(new NoCommandsTroll(plugin, this));
        register(new NoJumpTroll(plugin, this));
        register(new InvertedControlsTroll(plugin, this));
        register(new NoBreakTroll(plugin, this));
        register(new NoPlaceTroll(plugin, this));
        register(new NoAttackTroll(plugin, this));
        
        // ═══════════════════ ВИЗУАЛЬНЫЕ ═══════════════════
        register(new GlitchyTroll(plugin, this));
        register(new FakeExplosionTroll(plugin, this));
        register(new MatrixTroll(plugin, this));
        register(new DemoScreenTroll(plugin, this));
        register(new BouncyTroll(plugin, this));
        register(new PumpkinHeadTroll(plugin, this));
        register(new ScreenShakeTroll(plugin, this));
        
        // ═══════════════════ ОСОБЫЕ ═══════════════════
        register(new RocketTroll(plugin, this));
        register(new CageTroll(plugin, this));
        register(new WebTrapTroll(plugin, this));
        register(new FakeCrashTroll(plugin, this));
        register(new ControlTroll(plugin, this));
        register(new CloneTroll(plugin, this));
        register(new ExplosiveArrowsTroll(plugin, this));
        
        // ═══════════════════ НОВЫЕ УНИКАЛЬНЫЕ ═══════════════════
        register(new BlackHoleTroll(plugin, this));
        register(new MirrorTroll(plugin, this));
        register(new GhostTroll(plugin, this));
        register(new DiscoTroll(plugin, this));
        register(new EarthquakeTroll(plugin, this));
        register(new SlendermanTroll(plugin, this));
        register(new TornadoTroll(plugin, this));
        register(new DragonBreathTroll(plugin, this));
        register(new RainbowTroll(plugin, this));
        register(new GiantTroll(plugin, this));
        register(new SoulStealTroll(plugin, this));
        register(new TimerBombTroll(plugin, this));
        register(new HerobrineTroll(plugin, this));
        register(new LaserTroll(plugin, this));
        register(new AirStrikeTroll(plugin, this));
        register(new PortalTroll(plugin, this));
        register(new MatrixRainTroll(plugin, this));
        register(new FloorIsLavaTroll(plugin, this));
        register(new GravityWellTroll(plugin, this));
        register(new VirusTroll(plugin, this));
    }

    private void register(BaseTroll troll) {
        trolls.put(troll.getId(), troll);
    }

    public BaseTroll getTroll(String id) {
        return trolls.get(id.toLowerCase());
    }

    public Collection<BaseTroll> getAllTrolls() {
        return trolls.values();
    }

    public List<BaseTroll> getTrollsByCategory(BaseTroll.TrollCategory category) {
        return trolls.values().stream()
            .filter(t -> t.getCategory() == category)
            .toList();
    }

    public int getTrollCount() {
        return trolls.size();
    }

    public void executeTroll(String trollId, Player target, Player executor) {
        BaseTroll troll = getTroll(trollId);
        if (troll != null) {
            troll.execute(target, executor);
        }
    }

    public void clearAll() {
        frozen.clear();
        blinded.clear();
        confused.clear();
        noPickup.clear();
        noDrop.clear();
        noChat.clear();
        noCommands.clear();
        invertedControls.clear();
        burning.clear();
        starving.clear();
        slowMining.clear();
        noJump.clear();
        bouncy.clear();
        drunk.clear();
        paranoid.clear();
        glitchy.clear();
        noBreak.clear();
        noPlace.clear();
        fakeOp.clear();
        gravityReverse.clear();
    }

    public void clearPlayer(Player player) {
        UUID uuid = player.getUniqueId();
        frozen.remove(uuid);
        blinded.remove(uuid);
        confused.remove(uuid);
        noPickup.remove(uuid);
        noDrop.remove(uuid);
        noChat.remove(uuid);
        noCommands.remove(uuid);
        invertedControls.remove(uuid);
        burning.remove(uuid);
        starving.remove(uuid);
        slowMining.remove(uuid);
        noJump.remove(uuid);
        bouncy.remove(uuid);
        drunk.remove(uuid);
        paranoid.remove(uuid);
        glitchy.remove(uuid);
        noBreak.remove(uuid);
        noPlace.remove(uuid);
        fakeOp.remove(uuid);
        gravityReverse.remove(uuid);
        
        // Убираем все эффекты
        player.getActivePotionEffects().forEach(e -> player.removePotionEffect(e.getType()));
        player.setWalkSpeed(0.2f);
        player.setFlySpeed(0.1f);
    }

    // ═══════════════════ ГЕТТЕРЫ СОСТОЯНИЙ ═══════════════════
    public Set<UUID> getFrozen() { return frozen; }
    public Set<UUID> getBlinded() { return blinded; }
    public Set<UUID> getConfused() { return confused; }
    public Set<UUID> getNoPickup() { return noPickup; }
    public Set<UUID> getNoDrop() { return noDrop; }
    public Set<UUID> getNoChat() { return noChat; }
    public Set<UUID> getNoCommands() { return noCommands; }
    public Set<UUID> getInvertedControls() { return invertedControls; }
    public Set<UUID> getBurning() { return burning; }
    public Set<UUID> getStarving() { return starving; }
    public Set<UUID> getSlowMining() { return slowMining; }
    public Set<UUID> getNoJump() { return noJump; }
    public Set<UUID> getBouncy() { return bouncy; }
    public Set<UUID> getDrunk() { return drunk; }
    public Set<UUID> getParanoid() { return paranoid; }
    public Set<UUID> getGlitchy() { return glitchy; }
    public Set<UUID> getNoBreak() { return noBreak; }
    public Set<UUID> getNoPlace() { return noPlace; }
    public Set<UUID> getFakeOp() { return fakeOp; }
    public Set<UUID> getGravityReverse() { return gravityReverse; }

    // Методы проверки
    public boolean isFrozen(Player p) { return frozen.contains(p.getUniqueId()); }
    public boolean isBlinded(Player p) { return blinded.contains(p.getUniqueId()); }
    public boolean isNoPickup(Player p) { return noPickup.contains(p.getUniqueId()); }
    public boolean isNoDrop(Player p) { return noDrop.contains(p.getUniqueId()); }
    public boolean isNoChat(Player p) { return noChat.contains(p.getUniqueId()); }
    public boolean isNoCommands(Player p) { return noCommands.contains(p.getUniqueId()); }
    public boolean isNoJump(Player p) { return noJump.contains(p.getUniqueId()); }
    public boolean isBouncy(Player p) { return bouncy.contains(p.getUniqueId()); }
    public boolean isGlitchy(Player p) { return glitchy.contains(p.getUniqueId()); }
    public boolean isParanoid(Player p) { return paranoid.contains(p.getUniqueId()); }
    public boolean isNoBreak(Player p) { return noBreak.contains(p.getUniqueId()); }
    public boolean isNoPlace(Player p) { return noPlace.contains(p.getUniqueId()); }
    public boolean isGravityReverse(Player p) { return gravityReverse.contains(p.getUniqueId()); }
}
