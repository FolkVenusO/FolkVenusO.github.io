package sx.project.sxtroll.trolls;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class FakeDeathTroll extends BaseTroll {
    public FakeDeathTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "fakedeath", "&4☠ Фейк смерть", "Фейковое сообщение о смерти", Material.SKELETON_SKULL, TrollCategory.CHAT);
    }
    @Override
    public void execute(Player target, Player executor) {
        Bukkit.broadcastMessage("§7" + target.getName() + " был убит магией");
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
