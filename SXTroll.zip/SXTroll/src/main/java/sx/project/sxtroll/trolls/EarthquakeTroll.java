package sx.project.sxtroll.trolls;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;
import java.util.concurrent.ThreadLocalRandom;

public class EarthquakeTroll extends BaseTroll {
    public EarthquakeTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "earthquake", "&6🌋 Землетрясение", "Вызвать землетрясение", Material.CRACKED_STONE_BRICKS, TrollCategory.SPECIAL);
    }

    @Override
    public void execute(Player target, Player executor) {
        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (!target.isOnline() || ticks >= 100) { cancel(); return; }
                
                // Тряска
                double shakeX = (ThreadLocalRandom.current().nextDouble() - 0.5) * 0.5;
                double shakeZ = (ThreadLocalRandom.current().nextDouble() - 0.5) * 0.5;
                target.setVelocity(new Vector(shakeX, 0.1, shakeZ));
                
                // Частицы земли
                Location loc = target.getLocation();
                target.getWorld().spawnParticle(Particle.BLOCK, loc, 20, 2, 0.1, 2, 0.1, Material.DIRT.createBlockData());
                
                // Звуки
                if (ticks % 5 == 0) {
                    target.playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 0.3f, 0.5f);
                }
                
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 2L);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
