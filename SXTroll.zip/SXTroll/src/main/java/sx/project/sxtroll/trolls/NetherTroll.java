package sx.project.sxtroll.trolls;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Player;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class NetherTroll extends BaseTroll {
    public NetherTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "nether", "&4🔥 В незер", "Телепортировать в незер", Material.NETHERRACK, TrollCategory.TELEPORT);
    }

    @Override
    public void execute(Player target, Player executor) {
        World nether = Bukkit.getWorld("world_nether");
        if (nether == null) {
            for (World w : Bukkit.getWorlds()) {
                if (w.getEnvironment() == World.Environment.NETHER) {
                    nether = w;
                    break;
                }
            }
        }
        if (nether != null) {
            Location loc = new Location(nether, 0, 100, 0);
            loc.setY(nether.getHighestBlockYAt(0, 0) + 1);
            target.teleport(loc);
        }
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
