package sx.project.sxtroll.trolls;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class RainbowTroll extends BaseTroll {
    private static final Color[] RAINBOW = {Color.RED, Color.ORANGE, Color.YELLOW, Color.GREEN, Color.AQUA, Color.BLUE, Color.PURPLE};
    
    public RainbowTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "rainbow", "&c&lР&6&lа&e&lд&a&lу&b&lг&9&lа", "Окружить радужными частицами", Material.PRISMARINE_SHARD, TrollCategory.VISUAL);
    }

    @Override
    public void execute(Player target, Player executor) {
        new BukkitRunnable() {
            int ticks = 0;
            double angle = 0;
            @Override
            public void run() {
                if (!target.isOnline() || ticks >= 200) { cancel(); return; }
                
                Location loc = target.getLocation().add(0, 1, 0);
                for (int i = 0; i < RAINBOW.length; i++) {
                    double offsetAngle = angle + (i * Math.PI * 2 / RAINBOW.length);
                    double x = Math.cos(offsetAngle) * 1.5;
                    double z = Math.sin(offsetAngle) * 1.5;
                    double y = Math.sin(angle * 2 + i) * 0.5;
                    
                    Particle.DustOptions dust = new Particle.DustOptions(RAINBOW[i], 1.2f);
                    loc.getWorld().spawnParticle(Particle.DUST, loc.clone().add(x, y, z), 1, 0, 0, 0, 0, dust);
                }
                angle += 0.15;
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
