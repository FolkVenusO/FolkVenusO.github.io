package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Giant;
import org.bukkit.entity.Player;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class GiantTroll extends BaseTroll {
    public GiantTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "giant", "&2🗿 Гигант", "Заспавнить гигантского зомби", Material.ZOMBIE_HEAD, TrollCategory.MOBS);
    }

    @Override
    public void execute(Player target, Player executor) {
        Giant giant = (Giant) target.getWorld().spawnEntity(target.getLocation().add(5, 0, 5), EntityType.GIANT);
        giant.setTarget(target);
        target.playSound(target.getLocation(), Sound.ENTITY_WARDEN_ROAR, 1f, 0.5f);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
