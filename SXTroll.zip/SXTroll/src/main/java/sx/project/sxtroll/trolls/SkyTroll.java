package sx.project.sxtroll.trolls;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class SkyTroll extends BaseTroll {
    public SkyTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "sky", "&b☁ В небо", "Телепортировать в небо", Material.WHITE_WOOL, TrollCategory.TELEPORT);
    }

    @Override
    public void execute(Player target, Player executor) {
        Location loc = target.getLocation();
        loc.setY(300);
        target.teleport(loc);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
