package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;
import java.util.concurrent.ThreadLocalRandom;

public class FakeSoundTroll extends BaseTroll {
    private static final Sound[] SCARY_SOUNDS = {Sound.ENTITY_GHAST_SCREAM, Sound.ENTITY_WITHER_SPAWN, Sound.ENTITY_ENDER_DRAGON_GROWL, Sound.AMBIENT_CAVE, Sound.ENTITY_CREEPER_PRIMED};
    public FakeSoundTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "fakesound", "&e🔊 Страшный звук", "Воспроизвести страшный звук", Material.NOTE_BLOCK, TrollCategory.CHAT);
    }
    @Override
    public void execute(Player target, Player executor) {
        Sound s = SCARY_SOUNDS[ThreadLocalRandom.current().nextInt(SCARY_SOUNDS.length)];
        target.playSound(target.getLocation(), s, 1f, 1f);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
