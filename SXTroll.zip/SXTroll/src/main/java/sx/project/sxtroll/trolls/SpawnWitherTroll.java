package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.entity.*;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class SpawnWitherTroll extends BaseTroll {
    public SpawnWitherTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "wither_boss", "&8💀 Визер", "Заспавнить Визера", Material.WITHER_SKELETON_SKULL, TrollCategory.MOBS);
    }
    @Override
    public void execute(Player target, Player executor) {
        target.getWorld().spawnEntity(target.getLocation().add(0, 3, 0), EntityType.WITHER);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
