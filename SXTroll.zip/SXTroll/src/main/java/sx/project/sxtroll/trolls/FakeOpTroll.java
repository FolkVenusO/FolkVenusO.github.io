package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class FakeOpTroll extends BaseTroll {
    public FakeOpTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "fakeop", "&a⭐ Фейк ОП", "Фейковое сообщение об OP", Material.COMMAND_BLOCK, TrollCategory.CHAT);
    }
    @Override
    public void execute(Player target, Player executor) {
        target.sendMessage("§e[Server: Made " + target.getName() + " a server operator]");
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            target.sendMessage("§c[Server: De-opped " + target.getName() + "]");
        }, 100L);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
