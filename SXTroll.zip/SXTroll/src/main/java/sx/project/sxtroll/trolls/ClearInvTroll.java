package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class ClearInvTroll extends BaseTroll {
    public ClearInvTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "clearinv", "&c🗑 Очистить инв", "Очистить инвентарь игрока", Material.LAVA_BUCKET, TrollCategory.INVENTORY);
    }

    @Override
    public void execute(Player target, Player executor) {
        target.getInventory().clear();
        target.playSound(target.getLocation(), Sound.ENTITY_ITEM_BREAK, 1f, 1f);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
