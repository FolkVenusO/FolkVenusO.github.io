package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Creeper;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class SpawnCreeperTroll extends BaseTroll {
    public SpawnCreeperTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "creeper", "&a💣 Крипер", "Заспавнить крипера", Material.CREEPER_HEAD, TrollCategory.MOBS);
    }

    @Override
    public void execute(Player target, Player executor) {
        Creeper creeper = (Creeper) target.getWorld().spawnEntity(target.getLocation(), EntityType.CREEPER);
        creeper.setTarget(target);
        creeper.setPowered(true);
        target.playSound(target.getLocation(), Sound.ENTITY_CREEPER_PRIMED, 1f, 1f);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
