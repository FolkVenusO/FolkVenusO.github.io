package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class CloneTroll extends BaseTroll {
    public CloneTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "clone", "&a👤 Клон", "Телепортироваться к цели", Material.ARMOR_STAND, TrollCategory.SPECIAL);
    }
    @Override
    public void execute(Player target, Player executor) {
        executor.teleport(target.getLocation());
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
