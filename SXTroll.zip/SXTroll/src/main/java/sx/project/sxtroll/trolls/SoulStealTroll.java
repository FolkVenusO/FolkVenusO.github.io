package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class SoulStealTroll extends BaseTroll {
    public SoulStealTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "soulsteal", "&5💜 Похищение души", "Эффект похищения души", Material.SOUL_LANTERN, TrollCategory.VISUAL);
    }

    @Override
    public void execute(Player target, Player executor) {
        target.playSound(target.getLocation(), Sound.ENTITY_WARDEN_HEARTBEAT, 1f, 0.5f);
        
        new BukkitRunnable() {
            int ticks = 0;
            double height = 0;
            @Override
            public void run() {
                if (!target.isOnline() || ticks >= 60) { cancel(); return; }
                
                // Частицы души поднимаются вверх
                for (int i = 0; i < 3; i++) {
                    double angle = Math.random() * Math.PI * 2;
                    double radius = 0.5;
                    double x = Math.cos(angle) * radius;
                    double z = Math.sin(angle) * radius;
                    target.getWorld().spawnParticle(Particle.SOUL, 
                        target.getLocation().add(x, height, z), 1, 0, 0.1, 0, 0.02);
                }
                
                height += 0.1;
                
                if (ticks == 30) {
                    target.playSound(target.getLocation(), Sound.ENTITY_WARDEN_DEATH, 0.5f, 1.5f);
                    target.damage(4);
                }
                
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
