package sx.project.sxtroll.trolls;

import net.kyori.adventure.title.Title;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;
import java.time.Duration;

public class FakeCrashTroll extends BaseTroll {
    public FakeCrashTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "fakecrash", "&c💥 Фейк краш", "Симулировать краш", Material.REDSTONE_BLOCK, TrollCategory.SPECIAL);
    }
    @Override
    public void execute(Player target, Player executor) {
        Title title = Title.title(Component.text("Saving chunks...", NamedTextColor.RED), Component.text("Server is restarting", NamedTextColor.GRAY), Title.Times.times(Duration.ofMillis(0), Duration.ofSeconds(5), Duration.ofMillis(500)));
        target.showTitle(title);
        target.getWorld().spawnParticle(Particle.FLASH, target.getLocation(), 100, 5, 5, 5, 1);
        target.playSound(target.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1f, 0.5f);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
