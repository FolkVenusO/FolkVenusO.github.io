package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class NoJumpTroll extends BaseTroll {
    public NoJumpTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "nojump", "&c⬆ Без прыжка", "Заблокировать прыжок", Material.SLIME_BLOCK, TrollCategory.BLOCKS);
    }
    @Override
    public void execute(Player target, Player executor) {
        if (manager.getNoJump().contains(target.getUniqueId())) {
            manager.getNoJump().remove(target.getUniqueId());
            target.removePotionEffect(PotionEffectType.JUMP_BOOST);
            plugin.getMessageUtils().send(executor, "troll.default.disabled", "{player}", target.getName());
        } else {
            manager.getNoJump().add(target.getUniqueId());
            target.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, Integer.MAX_VALUE, 250, false, false));
            plugin.getMessageUtils().send(executor, "troll.default.enabled", "{player}", target.getName());
        }
    }
    @Override public boolean isToggle() { return true; }
    @Override public boolean isActive(Player target) { return manager.getNoJump().contains(target.getUniqueId()); }
}
