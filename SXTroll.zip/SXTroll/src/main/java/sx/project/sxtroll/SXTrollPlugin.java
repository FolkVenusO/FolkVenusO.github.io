package sx.project.sxtroll;

import sx.project.sxtroll.commands.TrollCommand;
import sx.project.sxtroll.gui.TrollGUI;
import sx.project.sxtroll.listeners.GUIListener;
import sx.project.sxtroll.listeners.TrollListener;
import sx.project.sxtroll.managers.TrollManager;
import sx.project.sxtroll.utils.MessageUtils;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * ╔═══════════════════════════════════════════════════════════╗
 * ║                    SX PROJECT - SXTroll                   ║
 * ║           Премиум тролл-плагин для Minecraft              ║
 * ║                    60+ тролл-функций                      ║
 * ╚═══════════════════════════════════════════════════════════╝
 */
public class SXTrollPlugin extends JavaPlugin {

    private static SXTrollPlugin instance;
    private TrollManager trollManager;
    private TrollGUI trollGUI;
    private MessageUtils messageUtils;

    @Override
    public void onEnable() {
        instance = this;
        
        // Сохраняем конфиг
        saveDefaultConfig();
        
        // Инициализация компонентов
        this.messageUtils = new MessageUtils(this);
        this.trollManager = new TrollManager(this);
        this.trollGUI = new TrollGUI(this);

        // Регистрация команды
        TrollCommand trollCommand = new TrollCommand(this);
        getCommand("sxtroll").setExecutor(trollCommand);
        getCommand("sxtroll").setTabCompleter(trollCommand);

        // Регистрация слушателей
        getServer().getPluginManager().registerEvents(new GUIListener(this), this);
        getServer().getPluginManager().registerEvents(new TrollListener(this), this);
        
        // Красивый запуск
        getLogger().info("");
        getLogger().info("╔═══════════════════════════════════════════╗");
        getLogger().info("║         §b§lSX PROJECT §f- §6§lSXTroll            §r║");
        getLogger().info("║         §aVersion: §e" + getDescription().getVersion() + "                    §r║");
        getLogger().info("║         §aTrolls: §e" + trollManager.getTrollCount() + " функций               §r║");
        getLogger().info("╚═══════════════════════════════════════════╝");
        getLogger().info("");
    }

    @Override
    public void onDisable() {
        if (trollManager != null) {
            trollManager.clearAll();
        }
        getLogger().info("§c§lSXTroll §fвыключен!");
    }

    public void reloadPlugin() {
        reloadConfig();
        messageUtils = new MessageUtils(this);
        getLogger().info("§a§lSXTroll §fперезагружен!");
    }

    public static SXTrollPlugin getInstance() {
        return instance;
    }

    public TrollManager getTrollManager() {
        return trollManager;
    }

    public TrollGUI getTrollGUI() {
        return trollGUI;
    }

    public MessageUtils getMessageUtils() {
        return messageUtils;
    }
}
