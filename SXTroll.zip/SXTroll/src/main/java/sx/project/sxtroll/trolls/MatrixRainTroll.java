package sx.project.sxtroll.trolls;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;
import java.util.concurrent.ThreadLocalRandom;

public class MatrixRainTroll extends BaseTroll {
    private static final String MATRIX_CHARS = "ｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎﾏﾐﾑﾒﾓﾔﾕﾖﾗﾘﾙﾚﾛﾜﾝ01234567890";
    
    public MatrixRainTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "matrixrain", "&a💻 Дождь матрицы", "Заполнить чат кодом матрицы", Material.LIME_CONCRETE, TrollCategory.VISUAL);
    }

    @Override
    public void execute(Player target, Player executor) {
        new BukkitRunnable() {
            int lines = 0;
            @Override
            public void run() {
                if (!target.isOnline() || lines >= 30) { cancel(); return; }
                
                StringBuilder sb = new StringBuilder();
                int length = ThreadLocalRandom.current().nextInt(30, 60);
                for (int i = 0; i < length; i++) {
                    sb.append(MATRIX_CHARS.charAt(ThreadLocalRandom.current().nextInt(MATRIX_CHARS.length())));
                }
                
                NamedTextColor color = lines % 3 == 0 ? NamedTextColor.WHITE : NamedTextColor.GREEN;
                target.sendMessage(Component.text(sb.toString(), color).decorate(TextDecoration.BOLD));
                
                if (lines % 5 == 0) {
                    target.playSound(target.getLocation(), Sound.BLOCK_NOTE_BLOCK_BIT, 0.2f, 2f);
                }
                lines++;
            }
        }.runTaskTimer(plugin, 0L, 2L);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
