package sx.project.sxtroll.trolls;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.title.Title;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;
import java.time.Duration;

public class FloorIsLavaTroll extends BaseTroll {
    public FloorIsLavaTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "floorislava", "&c🌋 Пол - лава!", "Поджигать при касании земли", Material.MAGMA_BLOCK, TrollCategory.SPECIAL);
    }

    @Override
    public void execute(Player target, Player executor) {
        Title title = Title.title(
            Component.text("🔥 ПОЛ - ЭТО ЛАВА! 🔥", NamedTextColor.RED),
            Component.text("НЕ КАСАЙСЯ ЗЕМЛИ!", NamedTextColor.YELLOW),
            Title.Times.times(Duration.ZERO, Duration.ofSeconds(3), Duration.ofMillis(500))
        );
        target.showTitle(title);
        target.playSound(target.getLocation(), Sound.ENTITY_BLAZE_SHOOT, 1f, 1f);
        
        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (!target.isOnline() || ticks >= 300) { cancel(); return; }
                
                if (target.isOnGround()) {
                    target.setFireTicks(40);
                    target.damage(1);
                    target.getWorld().spawnParticle(Particle.FLAME, target.getLocation(), 20, 0.5, 0.1, 0.5, 0.05);
                    target.playSound(target.getLocation(), Sound.BLOCK_FIRE_AMBIENT, 0.5f, 1f);
                }
                
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
