package sx.project.sxtroll.trolls;

import net.kyori.adventure.title.Title;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;
import java.time.Duration;

public class FakeKickTroll extends BaseTroll {
    public FakeKickTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "fakekick", "&c🚪 Фейк кик", "Показать фейк экран кика", Material.IRON_DOOR, TrollCategory.CHAT);
    }
    @Override
    public void execute(Player target, Player executor) {
        Title title = Title.title(Component.text("Disconnected", NamedTextColor.RED), Component.text("Connection timed out", NamedTextColor.GRAY), Title.Times.times(Duration.ofMillis(0), Duration.ofSeconds(5), Duration.ofMillis(500)));
        target.showTitle(title);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
