package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class StarveTroll extends BaseTroll {
    public StarveTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "starve", "&6🍖 Голод", "Дать голод игроку", Material.ROTTEN_FLESH, TrollCategory.EFFECTS);
    }

    @Override
    public void execute(Player target, Player executor) {
        if (manager.getStarving().contains(target.getUniqueId())) {
            manager.getStarving().remove(target.getUniqueId());
            target.removePotionEffect(PotionEffectType.HUNGER);
            target.setFoodLevel(20);
            plugin.getMessageUtils().send(executor, "troll.default.disabled", "{player}", target.getName());
        } else {
            manager.getStarving().add(target.getUniqueId());
            target.addPotionEffect(new PotionEffect(PotionEffectType.HUNGER, Integer.MAX_VALUE, 5, false, false));
            target.setFoodLevel(0);
            target.setSaturation(0);
            plugin.getMessageUtils().send(executor, "troll.default.enabled", "{player}", target.getName());
        }
    }

    @Override public boolean isToggle() { return true; }
    @Override public boolean isActive(Player target) { return manager.getStarving().contains(target.getUniqueId()); }
}
