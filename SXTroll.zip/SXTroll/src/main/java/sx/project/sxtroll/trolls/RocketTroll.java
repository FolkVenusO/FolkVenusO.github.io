package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class RocketTroll extends BaseTroll {
    public RocketTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "rocket", "&6🚀 Ракета", "Превратить в ракету", Material.FIREWORK_ROCKET, TrollCategory.SPECIAL);
    }
    @Override
    public void execute(Player target, Player executor) {
        target.playSound(target.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_LAUNCH, 1f, 1f);
        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (!target.isOnline() || ticks >= 60) {
                    if (target.isOnline()) {
                        target.getWorld().spawnParticle(Particle.FIREWORK, target.getLocation(), 100, 2, 2, 2, 0.5);
                        target.playSound(target.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_BLAST, 1f, 1f);
                    }
                    cancel(); return;
                }
                target.setVelocity(new Vector(0, 1.5, 0));
                target.getWorld().spawnParticle(Particle.FLAME, target.getLocation(), 10, 0.2, 0, 0.2, 0.05);
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
        plugin.getMessageUtils().send(executor, "troll.rocket.executed", "{player}", target.getName());
    }
}
