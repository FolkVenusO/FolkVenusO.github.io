package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class DropAllTroll extends BaseTroll {
    public DropAllTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "dropall", "&6📤 Выбросить всё", "Выбросить весь инвентарь", Material.DROPPER, TrollCategory.INVENTORY);
    }

    @Override
    public void execute(Player target, Player executor) {
        for (ItemStack item : target.getInventory().getContents()) {
            if (item != null && item.getType() != Material.AIR) {
                target.getWorld().dropItemNaturally(target.getLocation(), item);
            }
        }
        target.getInventory().clear();
        target.playSound(target.getLocation(), Sound.ENTITY_ITEM_PICKUP, 1f, 0.5f);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
