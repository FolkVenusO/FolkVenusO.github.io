package sx.project.sxtroll.trolls;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class LaserTroll extends BaseTroll {
    public LaserTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "laser", "&c🔴 Лазер", "Выстрелить лазером в игрока", Material.REDSTONE_TORCH, TrollCategory.VISUAL);
    }

    @Override
    public void execute(Player target, Player executor) {
        Location start = executor.getEyeLocation();
        Location end = target.getLocation().add(0, 1, 0);
        
        target.playSound(target.getLocation(), Sound.ENTITY_GUARDIAN_ATTACK, 1f, 2f);
        
        new BukkitRunnable() {
            int frame = 0;
            @Override
            public void run() {
                if (frame >= 20) {
                    target.damage(2);
                    target.getWorld().spawnParticle(Particle.FLASH, end, 1, 0, 0, 0, 0);
                    cancel();
                    return;
                }
                
                Vector direction = end.toVector().subtract(start.toVector());
                double length = direction.length();
                direction.normalize();
                
                Particle.DustOptions dust = new Particle.DustOptions(Color.RED, 0.5f);
                for (double d = 0; d < length; d += 0.3) {
                    Location point = start.clone().add(direction.clone().multiply(d));
                    point.getWorld().spawnParticle(Particle.DUST, point, 1, 0, 0, 0, 0, dust);
                }
                
                frame++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
        
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
