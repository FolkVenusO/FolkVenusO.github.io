package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;
import java.util.concurrent.ThreadLocalRandom;

public class RandomSlotTroll extends BaseTroll {
    public RandomSlotTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "randomslot", "&d🎰 Рандом слот", "Постоянно менять слот", Material.COMPARATOR, TrollCategory.INVENTORY);
    }

    @Override
    public void execute(Player target, Player executor) {
        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (!target.isOnline() || ticks >= 100) { cancel(); return; }
                target.getInventory().setHeldItemSlot(ThreadLocalRandom.current().nextInt(9));
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 5L);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
