package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class SwapHandsTroll extends BaseTroll {
    public SwapHandsTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "swaphands", "&e🔄 Поменять руки", "Поменять местами руки", Material.ARROW, TrollCategory.INVENTORY);
    }

    @Override
    public void execute(Player target, Player executor) {
        ItemStack main = target.getInventory().getItemInMainHand();
        ItemStack off = target.getInventory().getItemInOffHand();
        target.getInventory().setItemInMainHand(off);
        target.getInventory().setItemInOffHand(main);
        target.playSound(target.getLocation(), Sound.ITEM_ARMOR_EQUIP_GENERIC, 1f, 1.5f);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
