package sx.project.sxtroll.trolls;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;
import java.util.concurrent.ThreadLocalRandom;

public class VirusTroll extends BaseTroll {
    private static final String[] VIRUS_MESSAGES = {
        "§c[VIRUS] §fАнализ системы... §e32%",
        "§c[VIRUS] §fОбнаружен файл: inventory.dat",
        "§c[VIRUS] §fУдаление данных... §c67%",
        "§c[VIRUS] §fШифрование файлов...",
        "§c[VIRUS] §fОтправка данных на удалённый сервер...",
        "§c[VIRUS] §fВзлом учётной записи... §a100%",
        "§a[АНТИВИРУС] §fУгроза нейтрализована!",
        "§a[АНТИВИРУС] §fЭто была шутка :)"
    };
    
    public VirusTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "virus", "&c🦠 Вирус", "Симуляция вирусной атаки", Material.FERMENTED_SPIDER_EYE, TrollCategory.CHAT);
    }

    @Override
    public void execute(Player target, Player executor) {
        new BukkitRunnable() {
            int index = 0;
            @Override
            public void run() {
                if (!target.isOnline() || index >= VIRUS_MESSAGES.length) { cancel(); return; }
                
                target.sendMessage(VIRUS_MESSAGES[index]);
                
                if (index < 6) {
                    target.playSound(target.getLocation(), Sound.BLOCK_NOTE_BLOCK_BIT, 0.5f, 0.5f);
                } else {
                    target.playSound(target.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.5f);
                }
                
                index++;
            }
        }.runTaskTimer(plugin, 0L, 30L);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
