package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class InvertedControlsTroll extends BaseTroll {
    public InvertedControlsTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "invert", "&d🔄 Инверсия", "Инвертировать управление", Material.COMPASS, TrollCategory.BLOCKS);
    }
    @Override
    public void execute(Player target, Player executor) {
        if (manager.getInvertedControls().contains(target.getUniqueId())) {
            manager.getInvertedControls().remove(target.getUniqueId());
            plugin.getMessageUtils().send(executor, "troll.default.disabled", "{player}", target.getName());
        } else {
            manager.getInvertedControls().add(target.getUniqueId());
            plugin.getMessageUtils().send(executor, "troll.default.enabled", "{player}", target.getName());
        }
    }
    @Override public boolean isToggle() { return true; }
    @Override public boolean isActive(Player target) { return manager.getInvertedControls().contains(target.getUniqueId()); }
}
