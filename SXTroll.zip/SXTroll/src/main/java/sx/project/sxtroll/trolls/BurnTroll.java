package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class BurnTroll extends BaseTroll {
    public BurnTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "burn", "&c🔥 Поджечь", "Поджечь игрока", Material.BLAZE_POWDER, TrollCategory.EFFECTS);
    }

    @Override
    public void execute(Player target, Player executor) {
        if (manager.getBurning().contains(target.getUniqueId())) {
            manager.getBurning().remove(target.getUniqueId());
            target.setFireTicks(0);
            plugin.getMessageUtils().send(executor, "troll.burn.disabled", "{player}", target.getName());
        } else {
            manager.getBurning().add(target.getUniqueId());
            target.setFireTicks(Integer.MAX_VALUE);
            target.getWorld().spawnParticle(Particle.FLAME, target.getLocation().add(0, 1, 0), 30, 0.3, 0.5, 0.3, 0.05);
            target.playSound(target.getLocation(), Sound.ENTITY_BLAZE_SHOOT, 1f, 1f);
            plugin.getMessageUtils().send(executor, "troll.burn.enabled", "{player}", target.getName());
        }
    }

    @Override public boolean isToggle() { return true; }
    @Override public boolean isActive(Player target) { return manager.getBurning().contains(target.getUniqueId()); }
}
