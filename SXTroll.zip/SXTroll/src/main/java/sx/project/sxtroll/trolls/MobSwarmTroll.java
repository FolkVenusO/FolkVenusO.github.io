package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.entity.*;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class MobSwarmTroll extends BaseTroll {
    public MobSwarmTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "swarm", "&4👹 Орда мобов", "Заспавнить орду", Material.SPAWNER, TrollCategory.MOBS);
    }
    @Override
    public void execute(Player target, Player executor) {
        EntityType[] types = {EntityType.ZOMBIE, EntityType.SKELETON, EntityType.SPIDER, EntityType.CREEPER};
        for (EntityType type : types) {
            for (int i = 0; i < 3; i++) {
                Entity e = target.getWorld().spawnEntity(target.getLocation(), type);
                if (e instanceof Monster m) m.setTarget(target);
            }
        }
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
