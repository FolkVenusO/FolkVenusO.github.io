package sx.project.sxtroll.trolls;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class SpinTroll extends BaseTroll {
    public SpinTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "spin", "&d🔄 Крутить", "Крутить игрока", Material.COMPASS, TrollCategory.TELEPORT);
    }

    @Override
    public void execute(Player target, Player executor) {
        new BukkitRunnable() {
            int ticks = 0;
            float yaw = target.getLocation().getYaw();
            @Override
            public void run() {
                if (!target.isOnline() || ticks >= 100) { cancel(); return; }
                Location loc = target.getLocation();
                yaw += 30;
                loc.setYaw(yaw);
                target.teleport(loc);
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
