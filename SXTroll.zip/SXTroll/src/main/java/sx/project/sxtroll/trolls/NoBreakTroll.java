package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class NoBreakTroll extends BaseTroll {
    public NoBreakTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "nobreak", "&c⛏ Без ломания", "Запретить ломать блоки", Material.BEDROCK, TrollCategory.BLOCKS);
    }
    @Override
    public void execute(Player target, Player executor) {
        if (manager.getNoBreak().contains(target.getUniqueId())) {
            manager.getNoBreak().remove(target.getUniqueId());
            plugin.getMessageUtils().send(executor, "troll.default.disabled", "{player}", target.getName());
        } else {
            manager.getNoBreak().add(target.getUniqueId());
            plugin.getMessageUtils().send(executor, "troll.default.enabled", "{player}", target.getName());
        }
    }
    @Override public boolean isToggle() { return true; }
    @Override public boolean isActive(Player target) { return manager.getNoBreak().contains(target.getUniqueId()); }
}
