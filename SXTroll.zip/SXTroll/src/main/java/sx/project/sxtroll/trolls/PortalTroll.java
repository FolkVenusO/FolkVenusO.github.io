package sx.project.sxtroll.trolls;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;
import java.util.concurrent.ThreadLocalRandom;

public class PortalTroll extends BaseTroll {
    public PortalTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "portal", "&5🌀 Портал", "Засосать в фейковый портал", Material.CRYING_OBSIDIAN, TrollCategory.TELEPORT);
    }

    @Override
    public void execute(Player target, Player executor) {
        Location portalLoc = target.getLocation().add(3, 0, 0);
        target.playSound(portalLoc, Sound.BLOCK_PORTAL_AMBIENT, 1f, 1f);
        
        new BukkitRunnable() {
            int ticks = 0;
            double angle = 0;
            @Override
            public void run() {
                if (!target.isOnline() || ticks >= 100) { cancel(); return; }
                
                // Рисуем портал
                for (double y = 0; y < 3; y += 0.2) {
                    for (double a = 0; a < Math.PI * 2; a += 0.5) {
                        double x = Math.cos(a + angle) * (1 - y * 0.2);
                        double z = Math.sin(a + angle) * 0.3;
                        portalLoc.getWorld().spawnParticle(Particle.PORTAL, 
                            portalLoc.clone().add(x, y, z), 1, 0, 0, 0, 0);
                    }
                }
                angle += 0.2;
                
                // Притягиваем игрока к порталу
                if (ticks > 30 && ticks < 80) {
                    target.setVelocity(portalLoc.toVector().subtract(target.getLocation().toVector()).normalize().multiply(0.3));
                }
                
                // Телепортируем в случайное место
                if (ticks == 80) {
                    target.playSound(target.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 0.5f);
                    Location newLoc = target.getLocation().add(
                        ThreadLocalRandom.current().nextInt(-20, 20),
                        0,
                        ThreadLocalRandom.current().nextInt(-20, 20)
                    );
                    newLoc.setY(target.getWorld().getHighestBlockYAt(newLoc) + 1);
                    target.teleport(newLoc);
                }
                
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
        
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
