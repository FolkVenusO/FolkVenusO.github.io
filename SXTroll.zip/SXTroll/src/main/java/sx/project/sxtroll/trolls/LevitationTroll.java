package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class LevitationTroll extends BaseTroll {
    public LevitationTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "levitate", "&f⬆ Левитация", "Дать левитацию игроку", Material.SHULKER_SHELL, TrollCategory.EFFECTS);
    }

    @Override
    public void execute(Player target, Player executor) {
        target.addPotionEffect(new PotionEffect(PotionEffectType.LEVITATION, 20 * 10, 2, false, true));
        target.playSound(target.getLocation(), Sound.ENTITY_SHULKER_BULLET_HIT, 1f, 1f);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
