package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.entity.*;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class SpawnSkeletonTroll extends BaseTroll {
    public SpawnSkeletonTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "skeleton", "&f💀 Скелет", "Заспавнить скелетов", Material.SKELETON_SKULL, TrollCategory.MOBS);
    }
    @Override
    public void execute(Player target, Player executor) {
        for (int i = 0; i < 3; i++) {
            Skeleton s = (Skeleton) target.getWorld().spawnEntity(target.getLocation(), EntityType.SKELETON);
            s.setTarget(target);
        }
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
