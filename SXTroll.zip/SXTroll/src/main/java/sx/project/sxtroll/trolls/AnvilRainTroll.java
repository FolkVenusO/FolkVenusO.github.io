package sx.project.sxtroll.trolls;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.*;
import org.bukkit.scheduler.BukkitRunnable;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class AnvilRainTroll extends BaseTroll {
    public AnvilRainTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "anvil", "&7🔨 Дождь наковален", "Сбросить наковальни", Material.ANVIL, TrollCategory.MOBS);
    }
    @Override
    public void execute(Player target, Player executor) {
        new BukkitRunnable() {
            int count = 0;
            @Override
            public void run() {
                if (!target.isOnline() || count >= 10) { cancel(); return; }
                Location loc = target.getLocation().add(0, 15, 0);
                FallingBlock anvil = target.getWorld().spawnFallingBlock(loc, Material.ANVIL.createBlockData());
                anvil.setDropItem(false);
                count++;
            }
        }.runTaskTimer(plugin, 0L, 10L);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
