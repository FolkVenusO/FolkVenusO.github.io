package sx.project.sxtroll.trolls;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;
import java.util.concurrent.ThreadLocalRandom;

public class SlendermanTroll extends BaseTroll {
    public SlendermanTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "slender", "&8🕴 Слендермен", "Преследовать игрока тёмной фигурой", Material.WITHER_SKELETON_SKULL, TrollCategory.SPECIAL);
    }

    @Override
    public void execute(Player target, Player executor) {
        Location spawnLoc = target.getLocation().add(
            ThreadLocalRandom.current().nextInt(-10, 10),
            0,
            ThreadLocalRandom.current().nextInt(-10, 10)
        );
        spawnLoc.setY(target.getWorld().getHighestBlockYAt(spawnLoc) + 1);
        
        ArmorStand slender = (ArmorStand) target.getWorld().spawnEntity(spawnLoc, EntityType.ARMOR_STAND);
        slender.setInvisible(false);
        slender.setGravity(false);
        slender.setInvulnerable(true);
        slender.setBasePlate(false);
        slender.getEquipment().setHelmet(new ItemStack(Material.WITHER_SKELETON_SKULL));
        slender.getEquipment().setChestplate(new ItemStack(Material.LEATHER_CHESTPLATE));
        slender.setCustomName("§8§l???");
        slender.setCustomNameVisible(true);
        
        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (!target.isOnline() || ticks >= 200 || slender.isDead()) {
                    slender.remove();
                    cancel();
                    return;
                }
                
                // Телепортируется ближе при отворачивании
                Location targetLoc = target.getLocation();
                Location slenderLoc = slender.getLocation();
                
                // Смотрит на игрока
                slenderLoc.setDirection(targetLoc.toVector().subtract(slenderLoc.toVector()));
                slender.teleport(slenderLoc);
                
                // Приближается
                if (ticks % 40 == 0 && slenderLoc.distance(targetLoc) > 3) {
                    Location newLoc = slenderLoc.clone().add(
                        targetLoc.toVector().subtract(slenderLoc.toVector()).normalize().multiply(2)
                    );
                    newLoc.setY(target.getWorld().getHighestBlockYAt(newLoc) + 1);
                    slender.teleport(newLoc);
                    target.playSound(target.getLocation(), Sound.AMBIENT_CAVE, 0.5f, 0.5f);
                    target.getWorld().spawnParticle(Particle.SMOKE, newLoc, 20, 0.5, 1, 0.5, 0.01);
                }
                
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
