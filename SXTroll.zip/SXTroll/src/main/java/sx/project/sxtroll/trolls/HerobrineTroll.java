package sx.project.sxtroll.trolls;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.scheduler.BukkitRunnable;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;
import java.util.concurrent.ThreadLocalRandom;

public class HerobrineTroll extends BaseTroll {
    public HerobrineTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "herobrine", "&f👁 Херобрин", "Призвать Херобрина", Material.PLAYER_HEAD, TrollCategory.SPECIAL);
    }

    @Override
    public void execute(Player target, Player executor) {
        // Отправляем пугающее сообщение
        target.sendMessage("§8[§4???§8] §fЯ наблюдаю за тобой...");
        target.playSound(target.getLocation(), Sound.AMBIENT_CAVE, 1f, 0.5f);
        
        // Спавним фигуру Херобрина вдалеке
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (!target.isOnline()) return;
            
            Location spawnLoc = target.getLocation().clone();
            spawnLoc.add(target.getLocation().getDirection().multiply(15));
            spawnLoc.setY(target.getWorld().getHighestBlockYAt(spawnLoc) + 1);
            
            ArmorStand herobrine = (ArmorStand) target.getWorld().spawnEntity(spawnLoc, EntityType.ARMOR_STAND);
            herobrine.setInvisible(true);
            herobrine.setGravity(false);
            herobrine.setInvulnerable(true);
            
            // Голова Херобрина
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta meta = (SkullMeta) head.getItemMeta();
            meta.setOwningPlayer(Bukkit.getOfflinePlayer("Herobrine"));
            head.setItemMeta(meta);
            herobrine.getEquipment().setHelmet(head);
            
            // Смотрит на игрока
            spawnLoc.setDirection(target.getLocation().toVector().subtract(spawnLoc.toVector()));
            herobrine.teleport(spawnLoc);
            
            // Частицы глаз
            new BukkitRunnable() {
                int ticks = 0;
                @Override
                public void run() {
                    if (ticks >= 100 || herobrine.isDead()) {
                        herobrine.remove();
                        cancel();
                        return;
                    }
                    
                    Location eyeLoc = herobrine.getLocation().add(0, 1.7, 0);
                    herobrine.getWorld().spawnParticle(Particle.END_ROD, eyeLoc, 2, 0.1, 0, 0.1, 0);
                    
                    // Случайные звуки
                    if (ThreadLocalRandom.current().nextInt(50) == 0) {
                        target.playSound(target.getLocation(), Sound.ENTITY_ENDERMAN_STARE, 0.3f, 0.5f);
                    }
                    
                    ticks++;
                }
            }.runTaskTimer(plugin, 0L, 1L);
            
        }, 40L);
        
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
