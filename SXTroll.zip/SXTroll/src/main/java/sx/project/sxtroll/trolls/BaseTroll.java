package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

/**
 * Базовый класс для всех тролл-функций SX PROJECT
 */
public abstract class BaseTroll {

    protected final SXTrollPlugin plugin;
    protected final TrollManager manager;
    protected final String id;
    protected final String name;
    protected final String description;
    protected final Material icon;
    protected final TrollCategory category;

    public BaseTroll(SXTrollPlugin plugin, TrollManager manager, String id, String name, 
                     String description, Material icon, TrollCategory category) {
        this.plugin = plugin;
        this.manager = manager;
        this.id = id.toLowerCase();
        this.name = name;
        this.description = description;
        this.icon = icon;
        this.category = category;
    }

    /**
     * Выполнить тролль на игрока
     */
    public abstract void execute(Player target, Player executor);

    /**
     * Является ли тролль переключаемым
     */
    public boolean isToggle() {
        return false;
    }

    /**
     * Активен ли тролль для игрока
     */
    public boolean isActive(Player target) {
        return false;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public String getDescription() { return description; }
    public Material getIcon() { return icon; }
    public TrollCategory getCategory() { return category; }

    /**
     * Категории троллей с красивыми иконками
     */
    public enum TrollCategory {
        EFFECTS("⚗ Эффекты", Material.POTION, "&d"),
        TELEPORT("🌀 Телепортация", Material.ENDER_PEARL, "&5"),
        INVENTORY("📦 Инвентарь", Material.CHEST, "&6"),
        MOBS("👹 Мобы", Material.ZOMBIE_HEAD, "&c"),
        CHAT("💬 Чат и звуки", Material.NOTE_BLOCK, "&e"),
        BLOCKS("🚫 Блокировки", Material.BARRIER, "&4"),
        VISUAL("👁 Визуальные", Material.ENDER_EYE, "&b"),
        SPECIAL("⭐ Особые", Material.NETHER_STAR, "&a");

        private final String displayName;
        private final Material icon;
        private final String color;

        TrollCategory(String displayName, Material icon, String color) {
            this.displayName = displayName;
            this.icon = icon;
            this.color = color;
        }

        public String getDisplayName() { return displayName; }
        public Material getIcon() { return icon; }
        public String getColor() { return color; }
    }
}
