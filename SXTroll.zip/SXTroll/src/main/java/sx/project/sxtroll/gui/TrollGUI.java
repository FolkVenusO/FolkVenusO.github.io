package sx.project.sxtroll.gui;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.scheduler.BukkitRunnable;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.trolls.BaseTroll;

import java.util.*;

/**
 * ╔═══════════════════════════════════════════════════════════╗
 * ║         SX PROJECT - Premium Troll GUI                    ║
 * ║         Красивое меню с анимациями и градиентами          ║
 * ╚═══════════════════════════════════════════════════════════╝
 */
public class TrollGUI {

    private final SXTrollPlugin plugin;
    private final LegacyComponentSerializer serializer = LegacyComponentSerializer.legacyAmpersand();
    
    private final Map<UUID, UUID> selectedTargets = new HashMap<>();
    private final Map<UUID, Integer> currentPages = new HashMap<>();
    private final Map<UUID, BaseTroll.TrollCategory> currentCategories = new HashMap<>();
    private final Map<UUID, BukkitRunnable> animations = new HashMap<>();

    // Красивые градиентные цвета SX PROJECT
    private static final TextColor SX_CYAN = TextColor.color(0, 255, 255);
    private static final TextColor SX_BLUE = TextColor.color(0, 150, 255);
    private static final TextColor SX_PURPLE = TextColor.color(150, 0, 255);
    private static final TextColor SX_PINK = TextColor.color(255, 0, 150);

    // Заголовки с брендингом
    public static final String MAIN_MENU_TITLE = "§8« §b§lSX§3§lTroll §8» §7Выбор цели";
    public static final String CATEGORY_MENU_TITLE = "§8« §b§lSX§3§lTroll §8» §7Категории";
    public static final String TROLLS_MENU_TITLE = "§8« §b§lSX§3§lTroll §8» §7";

    // Материалы для градиентной рамки
    private static final Material[] GRADIENT_GLASS = {
        Material.LIGHT_BLUE_STAINED_GLASS_PANE,
        Material.CYAN_STAINED_GLASS_PANE,
        Material.BLUE_STAINED_GLASS_PANE,
        Material.PURPLE_STAINED_GLASS_PANE,
        Material.MAGENTA_STAINED_GLASS_PANE
    };

    public TrollGUI(SXTrollPlugin plugin) {
        this.plugin = plugin;
    }

    /**
     * ═══════════════════ МЕНЮ ВЫБОРА ИГРОКА ═══════════════════
     */
    public void openPlayerSelectMenu(Player admin) {
        stopAnimation(admin);
        Collection<? extends Player> players = Bukkit.getOnlinePlayers();
        int rows = Math.max(4, Math.min(6, (players.size() / 7) + 3));
        int size = rows * 9;
        
        Inventory inv = Bukkit.createInventory(null, size, Component.text(MAIN_MENU_TITLE));
        
        // Анимированная градиентная рамка
        fillAnimatedBorder(inv, size, admin);
        
        // Заголовок - декоративный элемент
        inv.setItem(4, createDecorativeItem(Material.NETHER_STAR, 
            "&b&l⚡ &f&lSX&b&lTROLL &b&l⚡",
            "&7",
            "&7Выберите игрока для троллинга",
            "&7Онлайн: &a" + players.size() + " &7игроков",
            "&7",
            "&b▸ &fТроллей доступно: &e" + plugin.getTrollManager().getTrollCount()));
        
        // Головы игроков в красивой сетке
        int[] playerSlots = getPlayerSlots(size);
        int slotIndex = 0;
        
        for (Player target : players) {
            if (slotIndex >= playerSlots.length) break;
            
            ItemStack head = createAnimatedPlayerHead(target, admin);
            inv.setItem(playerSlots[slotIndex++], head);
        }
        
        // Нижняя панель управления
        int bottomRow = size - 9;
        inv.setItem(bottomRow + 3, createControlItem(Material.SUNFLOWER, 
            "&e&l⟳ &eОбновить", "&7Обновить список игроков"));
        inv.setItem(bottomRow + 5, createControlItem(Material.BOOK, 
            "&a&l? &aПомощь", "&7/sxtroll <игрок> [тролль]"));
        
        playOpenSound(admin);
        admin.openInventory(inv);
        
        // Запускаем анимацию рамки
        startBorderAnimation(admin, inv, size);
    }

    /**
     * ═══════════════════ МЕНЮ КАТЕГОРИЙ ═══════════════════
     */
    public void openCategoryMenu(Player admin, Player target) {
        stopAnimation(admin);
        selectedTargets.put(admin.getUniqueId(), target.getUniqueId());
        
        Inventory inv = Bukkit.createInventory(null, 54, Component.text(CATEGORY_MENU_TITLE));
        
        // Красивая рамка
        fillPremiumBorder(inv, 54);
        
        // Верхняя декорация
        inv.setItem(4, createDecorativeItem(Material.NETHER_STAR,
            "&b&l⚡ &f&lSX&b&lTROLL &b&l⚡",
            "&7",
            "&fВыберите категорию троллей"));
        
        // Информация о цели - красивая карточка
        inv.setItem(49, createTargetCard(target));
        
        // Категории в красивой сетке 
        BaseTroll.TrollCategory[] categories = BaseTroll.TrollCategory.values();
        int[] categorySlots = {19, 20, 21, 22, 23, 24, 25, 31};
        
        for (int i = 0; i < categories.length && i < categorySlots.length; i++) {
            BaseTroll.TrollCategory cat = categories[i];
            int count = plugin.getTrollManager().getTrollsByCategory(cat).size();
            
            ItemStack item = createCategoryItem(cat, count);
            inv.setItem(categorySlots[i], item);
        }
        
        // Нижняя панель
        inv.setItem(45, createControlItem(Material.ARROW, "&c&l← &cНазад", "&7К выбору игрока"));
        inv.setItem(47, createControlItem(Material.NETHER_STAR, "&d&l⭐ &dВсе троллы", 
            "&7Показать все &e" + plugin.getTrollManager().getTrollCount() + " &7троллей"));
        inv.setItem(51, createControlItem(Material.WATER_BUCKET, "&c&l🧹 &cОчистить", 
            "&7Снять все эффекты с цели"));
        inv.setItem(53, createControlItem(Material.REDSTONE, "&4&l⚠ &cОпасные", 
            "&7Самые мощные троллы"));
        
        playOpenSound(admin);
        admin.openInventory(inv);
        startPulseAnimation(admin, inv, categorySlots);
    }

    /**
     * ═══════════════════ МЕНЮ ТРОЛЛЕЙ ═══════════════════
     */
    public void openTrollsMenu(Player admin, BaseTroll.TrollCategory category, int page) {
        stopAnimation(admin);
        UUID targetUUID = selectedTargets.get(admin.getUniqueId());
        if (targetUUID == null) {
            openPlayerSelectMenu(admin);
            return;
        }
        
        Player target = Bukkit.getPlayer(targetUUID);
        if (target == null || !target.isOnline()) {
            plugin.getMessageUtils().send(admin, "target-offline");
            openPlayerSelectMenu(admin);
            return;
        }
        
        currentCategories.put(admin.getUniqueId(), category);
        currentPages.put(admin.getUniqueId(), page);
        
        List<BaseTroll> trolls;
        String title;
        String categoryColor = "&b";
        
        if (category == null) {
            trolls = new ArrayList<>(plugin.getTrollManager().getAllTrolls());
            title = TROLLS_MENU_TITLE + "Все троллы";
        } else {
            trolls = new ArrayList<>(plugin.getTrollManager().getTrollsByCategory(category));
            title = TROLLS_MENU_TITLE + category.getDisplayName();
            categoryColor = category.getColor();
        }
        
        int trollsPerPage = 36;
        int totalPages = Math.max(1, (int) Math.ceil(trolls.size() / (double) trollsPerPage));
        page = Math.max(0, Math.min(page, totalPages - 1));
        
        Inventory inv = Bukkit.createInventory(null, 54, 
            Component.text(title + " §8[" + (page + 1) + "/" + totalPages + "]"));
        
        // Троллы на странице с красивым оформлением
        int startIndex = page * trollsPerPage;
        for (int i = 0; i < trollsPerPage && startIndex + i < trolls.size(); i++) {
            BaseTroll troll = trolls.get(startIndex + i);
            ItemStack item = createTrollItem(troll, target);
            inv.setItem(i, item);
        }
        
        // Красивая нижняя панель
        fillBottomPanel(inv);
        
        // Навигация
        inv.setItem(45, createControlItem(Material.ARROW, "&c&l← &cКатегории", "&7Вернуться к категориям"));
        
        if (page > 0) {
            inv.setItem(48, createControlItem(Material.SPECTRAL_ARROW, "&e&l◄ &eНазад", "&7Страница " + page));
        } else {
            inv.setItem(48, createGlassPane(Material.GRAY_STAINED_GLASS_PANE));
        }
        
        // Карточка цели в центре
        inv.setItem(49, createTargetCard(target));
        
        if (page < totalPages - 1) {
            inv.setItem(50, createControlItem(Material.SPECTRAL_ARROW, "&e&l► &eВперёд", "&7Страница " + (page + 2)));
        } else {
            inv.setItem(50, createGlassPane(Material.GRAY_STAINED_GLASS_PANE));
        }
        
        inv.setItem(53, createControlItem(Material.WATER_BUCKET, "&c&l🧹 &cОчистить", "&7Снять все эффекты"));
        
        playOpenSound(admin);
        admin.openInventory(inv);
    }

    // ═══════════════════ СОЗДАНИЕ ПРЕДМЕТОВ ═══════════════════

    private ItemStack createAnimatedPlayerHead(Player target, Player admin) {
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) head.getItemMeta();
        meta.setOwningPlayer(target);
        
        boolean isSelf = target.equals(admin);
        boolean isOp = target.isOp();
        
        // Градиентное имя
        String prefix = isSelf ? "&a&l✦ " : (isOp ? "&c&l♦ " : "&e&l◆ ");
        String suffix = isSelf ? " &7(Вы)" : (isOp ? " &c[OP]" : "");
        
        meta.displayName(serializer.deserialize(prefix + "&f" + target.getName() + suffix)
            .decoration(TextDecoration.ITALIC, false));
        
        List<Component> lore = new ArrayList<>();
        lore.add(Component.empty());
        lore.add(createLoreLine("&8▸ &7Здоровье: &c❤ " + String.format("%.0f", target.getHealth()) + "/" + String.format("%.0f", target.getMaxHealth())));
        lore.add(createLoreLine("&8▸ &7Голод: &6🍖 " + target.getFoodLevel() + "/20"));
        lore.add(createLoreLine("&8▸ &7Уровень: &a✦ " + target.getLevel()));
        lore.add(createLoreLine("&8▸ &7Мир: &b🌍 " + target.getWorld().getName()));
        lore.add(Component.empty());
        
        if (target.hasPermission("sxtroll.bypass") && !admin.hasPermission("sxtroll.admin")) {
            lore.add(createLoreLine("&c&l⚠ &cЗащищён от троллинга"));
        } else {
            lore.add(createLoreLine("&a▶ ЛКМ &7- Открыть меню троллинга"));
        }
        
        meta.lore(lore);
        head.setItemMeta(meta);
        return head;
    }

    private ItemStack createTargetCard(Player target) {
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) head.getItemMeta();
        meta.setOwningPlayer(target);
        
        meta.displayName(serializer.deserialize("&6&l⚡ &e&lЦЕЛЬ: &f&l" + target.getName() + " &6&l⚡")
            .decoration(TextDecoration.ITALIC, false));
        
        List<Component> lore = new ArrayList<>();
        lore.add(Component.empty());
        lore.add(createLoreLine("&8╔════════════════════╗"));
        lore.add(createLoreLine("&8║ &c❤ &f" + String.format("%.0f", target.getHealth()) + "&7/&f" + String.format("%.0f", target.getMaxHealth()) + " &8│ &6🍖 &f" + target.getFoodLevel() + "&7/&f20 &8║"));
        lore.add(createLoreLine("&8║ &a✦ &fУровень: &e" + target.getLevel() + "        &8║"));
        lore.add(createLoreLine("&8║ &b🌍 &f" + target.getWorld().getName() + "        &8║"));
        lore.add(createLoreLine("&8╚════════════════════╝"));
        lore.add(Component.empty());
        lore.add(createLoreLine("&7Режим: " + (target.getGameMode().name())));
        
        meta.lore(lore);
        meta.setEnchantmentGlintOverride(true);
        head.setItemMeta(meta);
        return head;
    }

    private ItemStack createCategoryItem(BaseTroll.TrollCategory category, int count) {
        ItemStack item = new ItemStack(category.getIcon());
        ItemMeta meta = item.getItemMeta();
        
        String color = category.getColor();
        meta.displayName(serializer.deserialize(color + "&l" + category.getDisplayName())
            .decoration(TextDecoration.ITALIC, false));
        
        List<Component> lore = new ArrayList<>();
        lore.add(Component.empty());
        lore.add(createLoreLine("&8▸ &7Троллей: &e" + count));
        lore.add(Component.empty());
        
        // Описания категорий
        String desc = switch (category) {
            case EFFECTS -> "&7Зелья и эффекты";
            case TELEPORT -> "&7Перемещение игрока";
            case INVENTORY -> "&7Действия с инвентарём";
            case MOBS -> "&7Спавн мобов";
            case CHAT -> "&7Сообщения и звуки";
            case BLOCKS -> "&7Блокировка действий";
            case VISUAL -> "&7Визуальные эффекты";
            case SPECIAL -> "&7Уникальные троллы";
        };
        lore.add(createLoreLine(desc));
        lore.add(Component.empty());
        lore.add(createLoreLine("&a▶ Клик &7- Открыть категорию"));
        
        meta.lore(lore);
        meta.setEnchantmentGlintOverride(true);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_ATTRIBUTES);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack createTrollItem(BaseTroll troll, Player target) {
        boolean isActive = troll.isToggle() && troll.isActive(target);
        
        ItemStack item = new ItemStack(troll.getIcon());
        ItemMeta meta = item.getItemMeta();
        
        // Название с статусом
        String statusIndicator = isActive ? " &a&l[ВКЛ]" : "";
        String nameColor = isActive ? "&a" : "&f";
        meta.displayName(serializer.deserialize(nameColor + troll.getName() + statusIndicator)
            .decoration(TextDecoration.ITALIC, false));
        
        List<Component> lore = new ArrayList<>();
        lore.add(Component.empty());
        lore.add(createLoreLine("&7" + troll.getDescription()));
        lore.add(Component.empty());
        
        // Тип тролля с иконкой
        if (troll.isToggle()) {
            lore.add(createLoreLine("&8▸ &7Тип: &e⚡ Переключатель"));
            String status = isActive ? "&a● ВКЛ" : "&c○ ВЫКЛ";
            lore.add(createLoreLine("&8▸ &7Статус: " + status));
        } else {
            lore.add(createLoreLine("&8▸ &7Тип: &b⚡ Мгновенный"));
        }
        
        lore.add(Component.empty());
        lore.add(createLoreLine("&a▶ Клик &7- " + (isActive ? "Выключить" : "Применить")));
        
        meta.lore(lore);
        
        if (isActive) {
            meta.setEnchantmentGlintOverride(true);
        }
        
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_ATTRIBUTES);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack createDecorativeItem(Material material, String name, String... lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(serializer.deserialize(name).decoration(TextDecoration.ITALIC, false));
        
        if (lore.length > 0) {
            List<Component> loreList = new ArrayList<>();
            for (String line : lore) {
                loreList.add(createLoreLine(line));
            }
            meta.lore(loreList);
        }
        
        meta.setEnchantmentGlintOverride(true);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_ATTRIBUTES);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack createControlItem(Material material, String name, String... lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(serializer.deserialize(name).decoration(TextDecoration.ITALIC, false));
        
        if (lore.length > 0) {
            List<Component> loreList = new ArrayList<>();
            for (String line : lore) {
                loreList.add(createLoreLine(line));
            }
            meta.lore(loreList);
        }
        
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack createGlassPane(Material material) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(" "));
        item.setItemMeta(meta);
        return item;
    }

    private Component createLoreLine(String text) {
        return serializer.deserialize(text).decoration(TextDecoration.ITALIC, false);
    }

    // ═══════════════════ ОФОРМЛЕНИЕ МЕНЮ ═══════════════════

    private void fillAnimatedBorder(Inventory inv, int size, Player admin) {
        for (int i = 0; i < 9; i++) {
            inv.setItem(i, createGlassPane(GRADIENT_GLASS[Math.min(i, 8-i)]));
        }
        for (int i = size - 9; i < size; i++) {
            int idx = i - (size - 9);
            inv.setItem(i, createGlassPane(GRADIENT_GLASS[Math.min(idx, 8-idx)]));
        }
        for (int i = 9; i < size - 9; i += 9) {
            inv.setItem(i, createGlassPane(Material.CYAN_STAINED_GLASS_PANE));
            inv.setItem(i + 8, createGlassPane(Material.CYAN_STAINED_GLASS_PANE));
        }
    }

    private void fillPremiumBorder(Inventory inv, int size) {
        Material[] corners = {Material.BLUE_STAINED_GLASS_PANE, Material.LIGHT_BLUE_STAINED_GLASS_PANE};
        
        // Верхний ряд - градиент
        for (int i = 0; i < 9; i++) {
            Material m = i < 2 || i > 6 ? corners[0] : (i < 4 || i > 4 ? corners[1] : Material.CYAN_STAINED_GLASS_PANE);
            inv.setItem(i, createGlassPane(m));
        }
        
        // Нижний ряд
        for (int i = size - 9; i < size; i++) {
            int idx = i - (size - 9);
            Material m = idx < 2 || idx > 6 ? corners[0] : (idx < 4 || idx > 4 ? corners[1] : Material.CYAN_STAINED_GLASS_PANE);
            inv.setItem(i, createGlassPane(m));
        }
        
        // Бока
        for (int i = 9; i < size - 9; i += 9) {
            inv.setItem(i, createGlassPane(corners[0]));
            inv.setItem(i + 8, createGlassPane(corners[0]));
        }
    }

    private void fillBottomPanel(Inventory inv) {
        for (int i = 45; i < 54; i++) {
            inv.setItem(i, createGlassPane(Material.GRAY_STAINED_GLASS_PANE));
        }
    }

    private int[] getPlayerSlots(int size) {
        List<Integer> slots = new ArrayList<>();
        for (int row = 1; row < (size / 9) - 1; row++) {
            for (int col = 1; col < 8; col++) {
                slots.add(row * 9 + col);
            }
        }
        return slots.stream().mapToInt(Integer::intValue).toArray();
    }

    // ═══════════════════ АНИМАЦИИ ═══════════════════

    private void startBorderAnimation(Player admin, Inventory inv, int size) {
        BukkitRunnable animation = new BukkitRunnable() {
            int frame = 0;
            final Material[] animColors = {
                Material.LIGHT_BLUE_STAINED_GLASS_PANE,
                Material.CYAN_STAINED_GLASS_PANE,
                Material.BLUE_STAINED_GLASS_PANE,
                Material.PURPLE_STAINED_GLASS_PANE,
                Material.BLUE_STAINED_GLASS_PANE,
                Material.CYAN_STAINED_GLASS_PANE
            };
            
            @Override
            public void run() {
                if (!admin.isOnline() || admin.getOpenInventory().getTopInventory() != inv) {
                    cancel();
                    return;
                }
                
                // Анимация верхнего ряда (пропускаем слот 4 - там звезда)
                for (int i = 0; i < 9; i++) {
                    if (i == 4) continue; // Пропускаем центральный декоративный элемент
                    int colorIndex = (i + frame) % animColors.length;
                    inv.setItem(i, createGlassPane(animColors[colorIndex]));
                }
                
                // Анимация нижнего ряда (пропускаем слоты с кнопками)
                int bottomStart = size - 9;
                for (int i = bottomStart; i < size; i++) {
                    int idx = i - bottomStart;
                    // Пропускаем слоты 3 и 5 (кнопки "Обновить" и "Помощь")
                    if (idx == 3 || idx == 5) continue;
                    int colorIndex = (8 - idx + frame) % animColors.length;
                    inv.setItem(i, createGlassPane(animColors[colorIndex]));
                }
                
                frame++;
            }
        };
        animation.runTaskTimer(plugin, 0L, 5L);
        animations.put(admin.getUniqueId(), animation);
    }

    private void startPulseAnimation(Player admin, Inventory inv, int[] slots) {
        BukkitRunnable animation = new BukkitRunnable() {
            int frame = 0;
            boolean glow = true;
            
            @Override
            public void run() {
                if (!admin.isOnline() || admin.getOpenInventory().getTopInventory() != inv) {
                    cancel();
                    return;
                }
                
                // Пульсация свечения на категориях каждые 20 тиков
                if (frame % 20 == 0) {
                    glow = !glow;
                    for (int slot : slots) {
                        ItemStack item = inv.getItem(slot);
                        if (item != null && item.hasItemMeta()) {
                            ItemMeta meta = item.getItemMeta();
                            meta.setEnchantmentGlintOverride(glow);
                            item.setItemMeta(meta);
                        }
                    }
                }
                
                frame++;
            }
        };
        animation.runTaskTimer(plugin, 0L, 1L);
        animations.put(admin.getUniqueId(), animation);
    }

    private void stopAnimation(Player admin) {
        BukkitRunnable anim = animations.remove(admin.getUniqueId());
        if (anim != null) {
            anim.cancel();
        }
    }

    // ═══════════════════ ЗВУКИ ═══════════════════

    private void playOpenSound(Player player) {
        if (plugin.getConfig().getBoolean("gui.click-sound", true)) {
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_CHIME, 0.5f, 2f);
        }
    }

    public void playClickSound(Player player) {
        if (plugin.getConfig().getBoolean("gui.click-sound", true)) {
            player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.5f, 1.2f);
        }
    }

    public void playSuccessSound(Player player) {
        player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.2f);
    }

    // ═══════════════════ ГЕТТЕРЫ ═══════════════════

    public UUID getSelectedTarget(Player admin) {
        return selectedTargets.get(admin.getUniqueId());
    }

    public int getCurrentPage(Player admin) {
        return currentPages.getOrDefault(admin.getUniqueId(), 0);
    }

    public BaseTroll.TrollCategory getCurrentCategory(Player admin) {
        return currentCategories.get(admin.getUniqueId());
    }

    public void clearData(Player admin) {
        stopAnimation(admin);
        selectedTargets.remove(admin.getUniqueId());
        currentPages.remove(admin.getUniqueId());
        currentCategories.remove(admin.getUniqueId());
    }
}
