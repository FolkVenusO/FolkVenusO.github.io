package sx.project.sxtroll.trolls;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class TornadoTroll extends BaseTroll {
    public TornadoTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "tornado", "&7🌪 Торнадо", "Закрутить игрока в торнадо", Material.WIND_CHARGE, TrollCategory.SPECIAL);
    }

    @Override
    public void execute(Player target, Player executor) {
        Location center = target.getLocation();
        new BukkitRunnable() {
            int ticks = 0;
            double angle = 0;
            double height = 0;
            @Override
            public void run() {
                if (!target.isOnline() || ticks >= 150) { cancel(); return; }
                
                // Визуальный торнадо
                for (double y = 0; y < 5; y += 0.3) {
                    double radius = 0.5 + y * 0.4;
                    double x = Math.cos(angle + y) * radius;
                    double z = Math.sin(angle + y) * radius;
                    center.getWorld().spawnParticle(Particle.CLOUD, center.clone().add(x, y, z), 1, 0, 0, 0, 0);
                }
                angle += 0.5;
                
                // Крутим игрока
                if (ticks < 100) {
                    double playerAngle = angle * 2;
                    double radius = 2;
                    Location newLoc = center.clone().add(
                        Math.cos(playerAngle) * radius,
                        height,
                        Math.sin(playerAngle) * radius
                    );
                    newLoc.setYaw((float) Math.toDegrees(playerAngle) + 90);
                    target.teleport(newLoc);
                    height += 0.05;
                } else {
                    // Выбрасываем
                    target.setVelocity(new Vector(
                        Math.cos(angle) * 2,
                        1,
                        Math.sin(angle) * 2
                    ));
                }
                
                if (ticks % 10 == 0) {
                    target.playSound(center, Sound.ENTITY_PHANTOM_FLAP, 1f, 0.5f);
                }
                
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
