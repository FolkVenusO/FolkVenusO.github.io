package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class NoPlaceTroll extends BaseTroll {
    public NoPlaceTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "noplace", "&c🧱 Без ставки", "Запретить ставить блоки", Material.COBBLESTONE, TrollCategory.BLOCKS);
    }
    @Override
    public void execute(Player target, Player executor) {
        if (manager.getNoPlace().contains(target.getUniqueId())) {
            manager.getNoPlace().remove(target.getUniqueId());
            plugin.getMessageUtils().send(executor, "troll.default.disabled", "{player}", target.getName());
        } else {
            manager.getNoPlace().add(target.getUniqueId());
            plugin.getMessageUtils().send(executor, "troll.default.enabled", "{player}", target.getName());
        }
    }
    @Override public boolean isToggle() { return true; }
    @Override public boolean isActive(Player target) { return manager.getNoPlace().contains(target.getUniqueId()); }
}
