package sx.project.sxtroll.trolls;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.AreaEffectCloud;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class DragonBreathTroll extends BaseTroll {
    public DragonBreathTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "dragonbreath", "&5🐉 Дыхание дракона", "Создать облако драконьего дыхания", Material.DRAGON_BREATH, TrollCategory.MOBS);
    }

    @Override
    public void execute(Player target, Player executor) {
        Location loc = target.getLocation();
        
        target.playSound(loc, Sound.ENTITY_ENDER_DRAGON_GROWL, 1f, 1f);
        target.getWorld().spawnParticle(Particle.DRAGON_BREATH, loc.add(0, 1, 0), 100, 2, 1, 2, 0.05);
        
        AreaEffectCloud cloud = (AreaEffectCloud) target.getWorld().spawnEntity(loc, EntityType.AREA_EFFECT_CLOUD);
        cloud.setRadius(3f);
        cloud.setDuration(200);
        cloud.setParticle(Particle.DRAGON_BREATH);
        cloud.addCustomEffect(new PotionEffect(PotionEffectType.INSTANT_DAMAGE, 1, 1), true);
        cloud.setRadiusPerTick(-0.01f);
        
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
