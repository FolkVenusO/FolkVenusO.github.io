package sx.project.sxtroll.trolls;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class WebTrapTroll extends BaseTroll {
    public WebTrapTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "webtrap", "&f🕸 Паутина", "Поймать в паутину", Material.COBWEB, TrollCategory.SPECIAL);
    }
    @Override
    public void execute(Player target, Player executor) {
        Location loc = target.getLocation();
        loc.getBlock().setType(Material.COBWEB);
        loc.clone().add(0, 1, 0).getBlock().setType(Material.COBWEB);
        new BukkitRunnable() {
            @Override
            public void run() {
                loc.getBlock().setType(Material.AIR);
                loc.clone().add(0, 1, 0).getBlock().setType(Material.AIR);
            }
        }.runTaskLater(plugin, 100L);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
