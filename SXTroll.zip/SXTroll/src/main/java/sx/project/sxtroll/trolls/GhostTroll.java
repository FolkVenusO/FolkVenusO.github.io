package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class GhostTroll extends BaseTroll {
    public GhostTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "ghost", "&f👻 Призрак", "Превратить в призрака с эффектами", Material.WHITE_CANDLE, TrollCategory.VISUAL);
    }

    @Override
    public void execute(Player target, Player executor) {
        target.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 20 * 30, 0, false, false));
        target.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_FALLING, 20 * 30, 0, false, false));
        target.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 20 * 30, 0, false, false));
        
        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (!target.isOnline() || ticks >= 600) { cancel(); return; }
                target.getWorld().spawnParticle(Particle.SOUL, target.getLocation().add(0, 1, 0), 3, 0.3, 0.5, 0.3, 0.01);
                if (ticks % 60 == 0) {
                    target.playSound(target.getLocation(), Sound.PARTICLE_SOUL_ESCAPE, 0.3f, 0.5f);
                }
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
