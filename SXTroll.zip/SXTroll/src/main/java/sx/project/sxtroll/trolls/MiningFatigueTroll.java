package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class MiningFatigueTroll extends BaseTroll {
    public MiningFatigueTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "fatigue", "&8⛏ Усталость", "Дать усталость копания", Material.ELDER_GUARDIAN_SPAWN_EGG, TrollCategory.EFFECTS);
    }

    @Override
    public void execute(Player target, Player executor) {
        target.addPotionEffect(new PotionEffect(PotionEffectType.MINING_FATIGUE, 20 * 120, 4, false, false));
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
