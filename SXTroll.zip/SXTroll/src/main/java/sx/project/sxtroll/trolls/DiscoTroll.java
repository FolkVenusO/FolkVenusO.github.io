package sx.project.sxtroll.trolls;

import org.bukkit.Color;
import org.bukkit.FireworkEffect;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.scheduler.BukkitRunnable;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;
import java.util.concurrent.ThreadLocalRandom;

public class DiscoTroll extends BaseTroll {
    private static final Color[] COLORS = {Color.RED, Color.ORANGE, Color.YELLOW, Color.GREEN, Color.AQUA, Color.BLUE, Color.PURPLE, Color.FUCHSIA};
    
    public DiscoTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "disco", "&d🪩 Дискотека", "Устроить дискотеку вокруг игрока", Material.GLOWSTONE, TrollCategory.VISUAL);
    }

    @Override
    public void execute(Player target, Player executor) {
        new BukkitRunnable() {
            int count = 0;
            @Override
            public void run() {
                if (!target.isOnline() || count >= 10) { cancel(); return; }
                
                Firework fw = target.getWorld().spawn(target.getLocation().add(0, 1, 0), Firework.class);
                FireworkMeta meta = fw.getFireworkMeta();
                
                Color c1 = COLORS[ThreadLocalRandom.current().nextInt(COLORS.length)];
                Color c2 = COLORS[ThreadLocalRandom.current().nextInt(COLORS.length)];
                
                meta.addEffect(FireworkEffect.builder()
                    .withColor(c1, c2)
                    .withFade(Color.WHITE)
                    .with(FireworkEffect.Type.BALL_LARGE)
                    .flicker(true)
                    .trail(true)
                    .build());
                meta.setPower(0);
                fw.setFireworkMeta(meta);
                
                plugin.getServer().getScheduler().runTaskLater(plugin, fw::detonate, 2L);
                target.playSound(target.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1f, 1f);
                count++;
            }
        }.runTaskTimer(plugin, 0L, 10L);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
