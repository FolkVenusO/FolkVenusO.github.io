package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.entity.*;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class SpawnTNTTroll extends BaseTroll {
    public SpawnTNTTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "tnt", "&c💣 ТНТ", "Заспавнить TNT", Material.TNT, TrollCategory.MOBS);
    }
    @Override
    public void execute(Player target, Player executor) {
        TNTPrimed tnt = (TNTPrimed) target.getWorld().spawnEntity(target.getLocation().add(0, 2, 0), EntityType.TNT);
        tnt.setFuseTicks(40);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
