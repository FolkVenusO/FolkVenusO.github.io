package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.entity.*;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class SpawnEndermanTroll extends BaseTroll {
    public SpawnEndermanTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "enderman", "&5👁 Эндермен", "Заспавнить эндермена", Material.ENDER_EYE, TrollCategory.MOBS);
    }
    @Override
    public void execute(Player target, Player executor) {
        Enderman e = (Enderman) target.getWorld().spawnEntity(target.getLocation(), EntityType.ENDERMAN);
        e.setTarget(target);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
