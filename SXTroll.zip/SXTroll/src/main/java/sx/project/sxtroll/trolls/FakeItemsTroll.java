package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class FakeItemsTroll extends BaseTroll {
    public FakeItemsTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "fakeitems", "&a💎 Фейк предметы", "Дать фейковые алмазы", Material.DIAMOND, TrollCategory.INVENTORY);
    }

    @Override
    public void execute(Player target, Player executor) {
        target.getInventory().addItem(new ItemStack(Material.DIAMOND, 64));
        target.playSound(target.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            target.getInventory().remove(Material.DIAMOND);
            target.playSound(target.getLocation(), Sound.ENTITY_ITEM_BREAK, 1f, 0.5f);
        }, 60L);
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
