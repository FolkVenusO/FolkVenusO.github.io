package sx.project.sxtroll.trolls;

import org.bukkit.Material;
import org.bukkit.entity.*;
import sx.project.sxtroll.SXTrollPlugin;
import sx.project.sxtroll.managers.TrollManager;

public class BeeSwarmTroll extends BaseTroll {
    public BeeSwarmTroll(SXTrollPlugin plugin, TrollManager manager) {
        super(plugin, manager, "bees", "&e🐝 Рой пчёл", "Заспавнить злых пчёл", Material.HONEYCOMB, TrollCategory.MOBS);
    }
    @Override
    public void execute(Player target, Player executor) {
        for (int i = 0; i < 10; i++) {
            Bee bee = (Bee) target.getWorld().spawnEntity(target.getLocation().add(0, 2, 0), EntityType.BEE);
            bee.setAnger(1000);
            bee.setTarget(target);
        }
        plugin.getMessageUtils().send(executor, "troll.default.executed", "{player}", target.getName());
    }
}
